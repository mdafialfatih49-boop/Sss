package com.dafi.milkupdate.client;

import com.dafi.milkupdate.MilkUpdateMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.client.render.RenderLayer;

public class MilkUpdateClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FluidRenderHandlerRegistry.INSTANCE.register(
                MilkUpdateMod.STILL_MILK,
                MilkUpdateMod.FLOWING_MILK,
                SimpleFluidRenderHandler.coloredWater(0xFFF5E2)
        );
        BlockRenderLayerMap.INSTANCE.putFluids(
                RenderLayer.getTranslucent(),
                MilkUpdateMod.STILL_MILK,
                MilkUpdateMod.FLOWING_MILK
        );
    }
}
