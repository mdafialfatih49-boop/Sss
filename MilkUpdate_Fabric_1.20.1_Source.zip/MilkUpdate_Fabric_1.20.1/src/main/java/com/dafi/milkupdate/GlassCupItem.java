package com.dafi.milkupdate;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;

/** Empty cup: right-click a still milk source to fill it. */
public class GlassCupItem extends Item {
    public GlassCupItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        FluidState fluidState = world.getFluidState(pos);

        if (fluidState.getFluid() != MilkUpdateMod.STILL_MILK || !fluidState.isStill()) {
            return ActionResult.PASS;
        }

        PlayerEntity player = context.getPlayer();
        if (player == null) {
            return ActionResult.PASS;
        }

        if (!world.isClient) {
            // Remove only the source block after collecting the milk.
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            world.playSound(null, pos, SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 0.8F, 1.1F);

            if (!player.getAbilities().creativeMode) {
                ItemStack held = context.getStack();
                ItemStack filledCup = new ItemStack(MilkUpdateMod.FILLED_GLASS_CUP);
                held.decrement(1);

                if (held.isEmpty()) {
                    player.setStackInHand(context.getHand(), filledCup);
                } else if (!player.getInventory().insertStack(filledCup)) {
                    player.dropItem(filledCup, false);
                }
            } else {
                // Creative players keep their empty cup and receive a filled one.
                player.getInventory().offerOrDrop(new ItemStack(MilkUpdateMod.FILLED_GLASS_CUP));
            }
        }

        return ActionResult.success(world.isClient);
    }
}
