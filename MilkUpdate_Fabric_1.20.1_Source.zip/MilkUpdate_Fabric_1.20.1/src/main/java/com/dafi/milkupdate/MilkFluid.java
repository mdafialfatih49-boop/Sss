package com.dafi.milkupdate;

import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/** Custom milk fluid with water-like flow speed. */
public abstract class MilkFluid extends FlowableFluid {
    @Override
    public Fluid getFlowing() {
        return MilkUpdateMod.FLOWING_MILK;
    }

    @Override
    public Fluid getStill() {
        return MilkUpdateMod.STILL_MILK;
    }

    @Override
    public Item getBucketItem() {
        return MilkUpdateMod.MILK_BUCKET;
    }

    @Override
    protected boolean isInfinite(World world) {
        // Milk sources do not regenerate infinitely like water sources.
        return false;
    }

    @Override
    protected void beforeBreakingBlock(WorldAccess world, BlockPos pos, BlockState state) {
        // Keep the fluid simple: it replaces soft blocks without extra side effects.
    }

    @Override
    public int getFlowSpeed(WorldView world) {
        return 4;
    }

    @Override
    public int getLevelDecreasePerBlock(WorldView world) {
        return 1;
    }

    @Override
    public int getTickRate(WorldView world) {
        return 5;
    }

    @Override
    protected float getBlastResistance() {
        return 100.0F;
    }

    @Override
    public boolean canBeReplacedWith(FluidState state, BlockView world, BlockPos pos, Fluid fluid, Direction direction) {
        return fluid == getStill() || fluid == getFlowing();
    }

    @Override
    public boolean matchesType(Fluid fluid) {
        return fluid == MilkUpdateMod.STILL_MILK || fluid == MilkUpdateMod.FLOWING_MILK;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
        super.appendProperties(builder);
    }

    @Override
    protected BlockState toBlockState(FluidState state) {
        return MilkUpdateMod.MILK_BLOCK.getDefaultState()
                .with(FluidBlock.LEVEL, getBlockStateLevel(state));
    }

    public static class Flowing extends MilkFluid {
        @Override
        protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
            super.appendProperties(builder);
            builder.add(LEVEL);
        }

        @Override
        public boolean isStill(FluidState state) {
            return false;
        }

        @Override
        public int getLevel(FluidState state) {
            return state.get(LEVEL);
        }
    }

    public static class Still extends MilkFluid {
        @Override
        public boolean isStill(FluidState state) {
            return true;
        }

        @Override
        public int getLevel(FluidState state) {
            return 8;
        }
    }
}
