package com.dafi.milkupdate;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MilkUpdateMod implements ModInitializer {
    public static final String MOD_ID = "milk_update";

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    public static final FlowableFluid STILL_MILK = Registry.register(
            Registries.FLUID, id("milk"), new MilkFluid.Still());
    public static final FlowableFluid FLOWING_MILK = Registry.register(
            Registries.FLUID, id("flowing_milk"), new MilkFluid.Flowing());

    public static final Item MILK_BUCKET = Registry.register(
            Registries.ITEM, id("milk_bucket"),
            new BucketItem(STILL_MILK, new Item.Settings().maxCount(1).recipeRemainder(Items.BUCKET)));

    public static final FluidBlock MILK_BLOCK = Registry.register(
            Registries.BLOCK, id("milk"),
            new FluidBlock(STILL_MILK, AbstractBlock.Settings.copy(Blocks.WATER)) {});

    public static final Item GLASS_CUP = Registry.register(
            Registries.ITEM, id("glass_cup"), new GlassCupItem(new Item.Settings().maxCount(16)));
    public static final Item FILLED_GLASS_CUP = Registry.register(
            Registries.ITEM, id("milk_glass"), new Item(new Item.Settings().maxCount(16)));

    public static final Block TABLE = Registry.register(
            Registries.BLOCK, id("table"),
            new TableBlock(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).strength(2.0F)));
    public static final Item TABLE_ITEM = Registry.register(
            Registries.ITEM, id("table"), new BlockItem(TABLE, new Item.Settings()));

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(entries -> {
            entries.add(GLASS_CUP);
            entries.add(FILLED_GLASS_CUP);
            entries.add(MILK_BUCKET);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> entries.add(TABLE_ITEM));
    }
}
