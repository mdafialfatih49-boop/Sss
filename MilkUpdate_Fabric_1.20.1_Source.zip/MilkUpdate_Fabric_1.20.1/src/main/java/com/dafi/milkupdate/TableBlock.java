package com.dafi.milkupdate;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.block.ShapeContext;

/** A small table with a tabletop and four legs. */
public class TableBlock extends Block {
    private static final VoxelShape SHAPE = VoxelShapes.union(
            Block.createCuboidShape(0, 12, 0, 16, 16, 16),
            Block.createCuboidShape(2, 0, 2, 4, 12, 4),
            Block.createCuboidShape(12, 0, 2, 14, 12, 4),
            Block.createCuboidShape(2, 0, 12, 4, 12, 14),
            Block.createCuboidShape(12, 0, 12, 14, 12, 14)
    );

    public TableBlock(Settings settings) {
        super(settings);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }
}
