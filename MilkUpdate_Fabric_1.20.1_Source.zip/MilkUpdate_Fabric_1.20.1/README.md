# Milk Update — Fabric 1.20.1

Mod sumber untuk Minecraft Java Edition **1.20.1 + Fabric**.

## Fitur yang dibuat

- **Milk Fluid**: susu menjadi fluid dunia dengan source dan flowing state, bergerak seperti air.
- **Milk Bucket**: ember khusus untuk meletakkan susu di dunia. Buat dari milk bucket vanilla melalui crafting shapeless.
- **Gelas kaca 3D**: klik kanan pada blok source susu yang diam untuk mengambil susu. Gelas berubah menjadi **Gelas Susu** 3D.
- **Meja kayu 3D**: blok meja dengan model dan collision shape mengikuti kaki serta permukaan meja.
- Bahasa item: Indonesia dan Inggris.

## Versi dan dependensi

- Minecraft Java 1.20.1
- Fabric Loader 0.15.11 atau lebih baru yang cocok dengan 1.20.1
- Fabric API 0.92.2+1.20.1
- Java 17
- Gradle 8.6

## Cara membuat file JAR lewat GitHub (bisa dari Android)

1. Ekstrak ZIP proyek ini.
2. Buat repository GitHub baru, lalu unggah **isi folder** proyek ini (folder `.github` juga harus ikut).
3. Buka tab **Actions** pada repository. Izinkan GitHub Actions jika diminta.
4. Jalankan workflow **Build Milk Update** lewat tombol **Run workflow**, atau lakukan push/commit.
5. Setelah status build hijau, buka hasil workflow dan cari bagian **Artifacts**.
6. Unduh artifact `MilkUpdate-Fabric-1.20.1`. Di dalamnya ada file mod `.jar`.

## Cara memasang mod

1. Pastikan Minecraft Java 1.20.1 sudah memakai Fabric Loader.
2. Pasang Fabric API 0.92.2+1.20.1 ke folder `mods`.
3. Salin `milk-update-1.0.0.jar` ke folder `mods`.
4. Jalankan profil Fabric 1.20.1.

## Cara bermain

- Craft **Gelas Kaca** dari 3 blok kaca (resep menghasilkan 4 gelas).
- Ambil susu dari sapi memakai ember vanilla, lalu craft **Ember Susu** dari milk bucket vanilla.
- Letakkan susu dengan Ember Susu.
- Klik kanan source susu yang diam menggunakan Gelas Kaca untuk mengambilnya.
- Craft **Meja Kayu** dari papan oak dan stick.

## Catatan teknis

Fluid susu disetel tidak membuat source tak terbatas. Gelas hanya mengambil **source block** susu yang diam, bukan aliran susu. Ini mencegah pengambilan dari aliran tipis dan membuat interaksi lebih konsisten.

Proyek ini menyertakan source code dan workflow build. File JAR belum dibundel; GitHub Actions akan mengompilasinya menjadi artifact.
