package com.voidtitan.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

/**
 * A three-metre hybrid boss. All abilities are server-side so multiplayer clients
 * see the same damage, knockback and teleport results.
 */
public class AbyssalColossusEntity extends HostileEntity {
    private final ServerBossBar bossBar = new ServerBossBar(
            Text.translatable("entity.voidtitan.abyssal_colossus"),
            BossBar.Color.PURPLE,
            BossBar.Style.PROGRESS
    );

    private int resonanceCooldown = 70;
    private int witherBurstCooldown = 145;
    private int wingCrashCooldown = 95;
    private int voidStepCooldown = 235;

    public AbyssalColossusEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 180;
        this.setStepHeight(1.25F);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 520.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.285D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 52.0D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 28.0D)
                .add(EntityAttributes.GENERIC_ATTACK_KNOCKBACK, 2.4D)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0D)
                .add(EntityAttributes.GENERIC_ARMOR, 22.0D)
                .add(EntityAttributes.GENERIC_ARMOR_TOUGHNESS, 14.0D);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.18D, true));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.75D));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 28.0F));
        this.goalSelector.add(4, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }

        this.bossBar.setPercent(Math.max(0.0F, this.getHealth() / this.getMaxHealth()));

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            return;
        }

        double distanceSquared = this.squaredDistanceTo(target);

        if (this.resonanceCooldown > 0) this.resonanceCooldown--;
        if (this.witherBurstCooldown > 0) this.witherBurstCooldown--;
        if (this.wingCrashCooldown > 0) this.wingCrashCooldown--;
        if (this.voidStepCooldown > 0) this.voidStepCooldown--;

        if (this.resonanceCooldown == 0 && distanceSquared <= 22.0D * 22.0D) {
            this.releaseResonanceWave(serverWorld);
            this.resonanceCooldown = 210;
        }

        if (this.witherBurstCooldown == 0 && distanceSquared <= 28.0D * 28.0D) {
            this.releaseWitherBurst(serverWorld, target);
            this.witherBurstCooldown = 250;
        }

        if (this.wingCrashCooldown == 0 && distanceSquared <= 10.5D * 10.5D) {
            this.crashWings(serverWorld);
            this.wingCrashCooldown = 155;
        }

        if (this.voidStepCooldown == 0 && distanceSquared >= 9.0D * 9.0D
                && distanceSquared <= 34.0D * 34.0D) {
            this.voidStep(serverWorld, target);
            this.voidStepCooldown = 285;
        }
    }

    private List<LivingEntity> getNearbyVictims(double radius) {
        return this.getWorld().getEntitiesByClass(
                LivingEntity.class,
                this.getBoundingBox().expand(radius),
                entity -> entity != this && !(entity instanceof AbyssalColossusEntity)
                        && entity.isAlive() && entity.squaredDistanceTo(this) <= radius * radius
        );
    }

    /** Warden-inspired pulse: a visible cyan ring that slows and pushes targets. */
    private void releaseResonanceWave(ServerWorld world) {
        this.playBossSound(world, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.7F, 0.72F);
        double ringRadius = 9.5D;
        for (int i = 0; i < 36; i++) {
            double angle = (Math.PI * 2.0D * i) / 36.0D;
            double px = this.getX() + Math.cos(angle) * ringRadius;
            double pz = this.getZ() + Math.sin(angle) * ringRadius;
            world.spawnParticles(ParticleTypes.SCULK_SOUL, px, this.getY() + 0.18D, pz,
                    2, 0.04D, 0.35D, 0.04D, 0.01D);
            world.spawnParticles(ParticleTypes.SOUL, px, this.getY() + 0.25D, pz,
                    1, 0.02D, 0.2D, 0.02D, 0.0D);
        }

        for (LivingEntity victim : this.getNearbyVictims(16.0D)) {
            victim.damage(this.getDamageSources().mobAttack(this), 16.0F);
            victim.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 90, 1));
            victim.takeKnockback(1.45D, this.getX() - victim.getX(), this.getZ() - victim.getZ());
        }
    }

    /** Wither-inspired triple-head energy blast. */
    private void releaseWitherBurst(ServerWorld world, LivingEntity target) {
        this.playBossSound(world, SoundEvents.ENTITY_WITHER_SHOOT, 2.4F, 0.68F);
        double startX = this.getX();
        double startY = this.getY() + 2.25D;
        double startZ = this.getZ();
        double endX = target.getX();
        double endY = target.getY() + Math.min(1.6D, target.getHeight() * 0.65D);
        double endZ = target.getZ();

        // Three staggered streams make the blast look as if it came from all heads.
        for (int stream = -1; stream <= 1; stream++) {
            for (int step = 1; step <= 12; step++) {
                double progress = step / 12.0D;
                double side = stream * 0.48D * (1.0D - progress);
                double x = startX + (endX - startX) * progress + side;
                double y = startY + (endY - startY) * progress;
                double z = startZ + (endZ - startZ) * progress - side;
                world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z,
                        3, 0.12D, 0.12D, 0.12D, 0.015D);
                world.spawnParticles(ParticleTypes.SMOKE, x, y, z,
                        1, 0.08D, 0.08D, 0.08D, 0.01D);
            }
        }

        if (target.isAlive() && this.squaredDistanceTo(target) <= 30.0D * 30.0D) {
            target.damage(this.getDamageSources().mobAttack(this), 23.0F);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 120, 1));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 35, 0));
            world.spawnParticles(ParticleTypes.SOUL, target.getX(), target.getY() + 1.0D,
                    target.getZ(), 34, 0.55D, 0.8D, 0.55D, 0.035D);
        }
    }

    /** Dragon-inspired double wing crash with a large non-destructive shockwave. */
    private void crashWings(ServerWorld world) {
        this.playBossSound(world, SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 3.0F, 0.62F);
        for (int i = 0; i < 44; i++) {
            double angle = (Math.PI * 2.0D * i) / 44.0D;
            double radius = 2.0D + (i % 4) * 1.7D;
            double px = this.getX() + Math.cos(angle) * radius;
            double pz = this.getZ() + Math.sin(angle) * radius;
            world.spawnParticles(ParticleTypes.DRAGON_BREATH, px, this.getY() + 0.15D,
                    pz, 2, 0.1D, 0.24D, 0.1D, 0.025D);
            world.spawnParticles(ParticleTypes.CLOUD, px, this.getY() + 0.1D,
                    pz, 1, 0.15D, 0.12D, 0.15D, 0.015D);
        }

        for (LivingEntity victim : this.getNearbyVictims(10.5D)) {
            victim.damage(this.getDamageSources().mobAttack(this), 25.0F);
            victim.takeKnockback(2.6D, this.getX() - victim.getX(), this.getZ() - victim.getZ());
            victim.addVelocity(0.0D, 0.42D, 0.0D);
        }
    }

    /** Ender-inspired short teleport that repositions the boss behind its target. */
    private void voidStep(ServerWorld world, LivingEntity target) {
        double oldX = this.getX();
        double oldY = this.getY();
        double oldZ = this.getZ();

        double dx = oldX - target.getX();
        double dz = oldZ - target.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 0.01D) {
            dx = 1.0D;
            dz = 0.0D;
            length = 1.0D;
        }

        double newX = target.getX() + (dx / length) * 3.8D;
        double newZ = target.getZ() + (dz / length) * 3.8D;

        world.spawnParticles(ParticleTypes.PORTAL, oldX, oldY + 1.5D, oldZ,
                48, 0.8D, 1.0D, 0.8D, 0.12D);
        this.requestTeleport(newX, target.getY(), newZ);
        world.spawnParticles(ParticleTypes.PORTAL, this.getX(), this.getY() + 1.4D,
                this.getZ(), 58, 0.9D, 1.0D, 0.9D, 0.14D);
        world.spawnParticles(ParticleTypes.REVERSE_PORTAL, this.getX(), this.getY() + 1.2D,
                this.getZ(), 30, 0.7D, 0.8D, 0.7D, 0.06D);
        this.playBossSound(world, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 2.6F, 0.72F);
    }

    private void playBossSound(ServerWorld world, net.minecraft.sound.SoundEvent sound,
                               float volume, float pitch) {
        world.playSound(null, this.getX(), this.getY(), this.getZ(), sound,
                SoundCategory.HOSTILE, volume, pitch);
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean successful = super.tryAttack(target);
        if (successful && target instanceof LivingEntity living) {
            living.takeKnockback(1.85D, this.getX() - living.getX(), this.getZ() - living.getZ());
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 50, 0));
        }
        return successful;
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    @Override
    protected void playStepSound(BlockPos pos, net.minecraft.block.BlockState state) {
        this.playSound(SoundEvents.ENTITY_IRON_GOLEM_STEP, 1.8F, 0.55F);
    }
}
