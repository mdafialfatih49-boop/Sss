package com.voidtitan;

import com.voidtitan.entity.AbyssalColossusEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VoidTitan implements ModInitializer {
    public static final String MOD_ID = "voidtitan";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final EntityType<AbyssalColossusEntity> ABYSSAL_COLOSSUS = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "abyssal_colossus"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, AbyssalColossusEntity::new)
                    .dimensions(EntityDimensions.fixed(2.65F, 3.05F))
                    .trackRangeBlocks(20)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final Item ABYSSAL_COLOSSUS_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(MOD_ID, "abyssal_colossus_spawn_egg"),
            new SpawnEggItem(ABYSSAL_COLOSSUS, 0x10172C, 0x28DDEB, new Item.Settings())
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(ABYSSAL_COLOSSUS, AbyssalColossusEntity.createAttributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(ABYSSAL_COLOSSUS_SPAWN_EGG));
        LOGGER.info("Abyssal Colossus has awakened.");
    }
}
