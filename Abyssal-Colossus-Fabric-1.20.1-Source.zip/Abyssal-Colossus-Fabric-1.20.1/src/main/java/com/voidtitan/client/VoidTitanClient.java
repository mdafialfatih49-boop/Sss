package com.voidtitan.client;

import com.voidtitan.VoidTitan;
import com.voidtitan.client.model.AbyssalColossusModel;
import com.voidtitan.client.renderer.AbyssalColossusRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class VoidTitanClient implements ClientModInitializer {
    public static final EntityModelLayer ABYSSAL_COLOSSUS_LAYER = new EntityModelLayer(
            new Identifier(VoidTitan.MOD_ID, "abyssal_colossus"), "main"
    );

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(
                ABYSSAL_COLOSSUS_LAYER,
                AbyssalColossusModel::getTexturedModelData
        );
        EntityRendererRegistry.register(
                VoidTitan.ABYSSAL_COLOSSUS,
                AbyssalColossusRenderer::new
        );
    }
}
