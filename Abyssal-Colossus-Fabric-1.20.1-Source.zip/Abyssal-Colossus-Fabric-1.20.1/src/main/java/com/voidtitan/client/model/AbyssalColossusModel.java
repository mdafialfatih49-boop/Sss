package com.voidtitan.client.model;

import com.voidtitan.entity.AbyssalColossusEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Blockbench-inspired low-poly model. Animation is evaluated every frame here,
 * so walk, sprint, wing motion and punch animation need no animation library.
 */
public class AbyssalColossusModel extends SinglePartEntityModel<AbyssalColossusEntity> {
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart leftHead;
    private final ModelPart rightHead;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart tail;

    public AbyssalColossusModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = torso.getChild("main_head");
        this.leftHead = torso.getChild("left_head");
        this.rightHead = torso.getChild("right_head");
        this.leftArm = torso.getChild("left_arm");
        this.rightArm = torso.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.leftWing = torso.getChild("left_wing");
        this.rightWing = torso.getChild("right_wing");
        this.tail = root.getChild("tail");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        ModelPartData torso = root.addChild("torso", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-8.0F, -14.0F, -5.0F, 16.0F, 19.0F, 10.0F)
                        .uv(0, 31).cuboid(-9.0F, -12.0F, -4.0F, 18.0F, 12.0F, 8.0F)
                        .uv(56, 0).cuboid(-7.0F, 2.0F, -4.0F, 14.0F, 5.0F, 8.0F),
                ModelTransform.pivot(0.0F, 0.0F, 0.0F));

        torso.addChild("core", ModelPartBuilder.create()
                        .uv(72, 31).cuboid(-4.0F, -5.0F, -0.9F, 8.0F, 9.0F, 1.8F)
                        .uv(92, 31).cuboid(-2.0F, -7.0F, -1.0F, 4.0F, 13.0F, 2.0F),
                ModelTransform.pivot(0.0F, -4.0F, -5.2F));

        ModelPartData mainHead = torso.addChild("main_head", ModelPartBuilder.create()
                        .uv(0, 62).cuboid(-5.0F, -8.0F, -4.5F, 10.0F, 9.0F, 9.0F)
                        .uv(40, 62).cuboid(-4.0F, -4.0F, -5.5F, 8.0F, 4.0F, 1.5F)
                        .uv(60, 62).cuboid(-5.0F, -12.0F, -2.0F, 2.0F, 6.0F, 2.0F)
                        .cuboid(3.0F, -12.0F, -2.0F, 2.0F, 6.0F, 2.0F)
                        .uv(78, 62).cuboid(-3.0F, -15.0F, 0.0F, 2.0F, 6.0F, 2.0F)
                        .cuboid(1.0F, -15.0F, 0.0F, 2.0F, 6.0F, 2.0F),
                ModelTransform.pivot(0.0F, -14.0F, 0.0F));
        mainHead.addChild("chin", ModelPartBuilder.create()
                        .uv(0, 82).cuboid(-3.5F, -1.0F, -5.0F, 7.0F, 3.0F, 2.0F),
                ModelTransform.pivot(0.0F, -1.0F, 0.0F));
        mainHead.addChild("glowing_eyes", ModelPartBuilder.create()
                        .uv(112, 104).cuboid(-3.2F, -5.7F, -4.95F, 2.0F, 1.2F, 0.5F)
                        .cuboid(1.2F, -5.7F, -4.95F, 2.0F, 1.2F, 0.5F),
                ModelTransform.NONE);

        ModelPartData leftHead = torso.addChild("left_head", ModelPartBuilder.create()
                        .uv(38, 82).cuboid(-3.0F, -3.5F, -3.0F, 6.0F, 7.0F, 6.0F)
                        .uv(62, 82).cuboid(-2.0F, 1.0F, -4.0F, 4.0F, 2.0F, 1.5F)
                        .uv(78, 82).cuboid(-4.0F, -7.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                ModelTransform.pivot(-8.0F, -11.0F, -0.5F));
        leftHead.addChild("glowing_eyes", ModelPartBuilder.create()
                        .uv(112, 104).cuboid(-2.2F, -1.5F, -3.2F, 1.5F, 1.0F, 0.5F)
                        .cuboid(0.6F, -1.5F, -3.2F, 1.5F, 1.0F, 0.5F),
                ModelTransform.NONE);

        ModelPartData rightHead = torso.addChild("right_head", ModelPartBuilder.create()
                        .uv(38, 82).cuboid(-3.0F, -3.5F, -3.0F, 6.0F, 7.0F, 6.0F)
                        .uv(62, 82).cuboid(-2.0F, 1.0F, -4.0F, 4.0F, 2.0F, 1.5F)
                        .uv(78, 82).cuboid(2.0F, -7.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                ModelTransform.pivot(8.0F, -11.0F, -0.5F));
        rightHead.addChild("glowing_eyes", ModelPartBuilder.create()
                        .uv(112, 104).cuboid(-2.2F, -1.5F, -3.2F, 1.5F, 1.0F, 0.5F)
                        .cuboid(0.6F, -1.5F, -3.2F, 1.5F, 1.0F, 0.5F),
                ModelTransform.NONE);

        ModelPartData leftArm = torso.addChild("left_arm", ModelPartBuilder.create()
                        .uv(0, 95).cuboid(-4.0F, -3.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                        .uv(32, 95).cuboid(-4.5F, 4.0F, -4.5F, 9.0F, 7.0F, 9.0F),
                ModelTransform.pivot(-10.0F, -8.0F, 0.0F));
        leftArm.addChild("left_fist", ModelPartBuilder.create()
                        .uv(68, 95).cuboid(-4.0F, 0.0F, -4.5F, 8.0F, 6.0F, 9.0F),
                ModelTransform.pivot(0.0F, 10.0F, -0.2F));

        ModelPartData rightArm = torso.addChild("right_arm", ModelPartBuilder.create()
                        .uv(0, 95).cuboid(-4.0F, -3.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                        .uv(32, 95).cuboid(-4.5F, 4.0F, -4.5F, 9.0F, 7.0F, 9.0F),
                ModelTransform.pivot(10.0F, -8.0F, 0.0F));
        rightArm.addChild("right_fist", ModelPartBuilder.create()
                        .uv(68, 95).cuboid(-4.0F, 0.0F, -4.5F, 8.0F, 6.0F, 9.0F),
                ModelTransform.pivot(0.0F, 10.0F, -0.2F));

        ModelPartData leftWing = torso.addChild("left_wing", ModelPartBuilder.create()
                        .uv(0, 92).cuboid(-20.0F, 0.0F, 0.0F, 19.0F, 22.0F, 0.8F)
                        .uv(40, 92).cuboid(-2.0F, -2.0F, 0.0F, 4.0F, 25.0F, 2.0F)
                        .uv(56, 100).cuboid(-2.0F, 4.0F, 1.0F, 2.0F, 17.0F, 1.0F),
                ModelTransform.pivot(-7.0F, -10.0F, 2.0F));
        leftWing.addChild("left_wing_tip", ModelPartBuilder.create()
                        .uv(24, 100).cuboid(-1.0F, 0.0F, 0.0F, 2.0F, 18.0F, 1.0F),
                ModelTransform.pivot(-1.0F, 19.0F, 0.0F));

        ModelPartData rightWing = torso.addChild("right_wing", ModelPartBuilder.create()
                        .uv(0, 92).cuboid(1.0F, 0.0F, 0.0F, 19.0F, 22.0F, 0.8F)
                        .uv(40, 92).cuboid(-2.0F, -2.0F, 0.0F, 4.0F, 25.0F, 2.0F)
                        .uv(56, 100).cuboid(0.0F, 4.0F, 1.0F, 2.0F, 17.0F, 1.0F),
                ModelTransform.pivot(7.0F, -10.0F, 2.0F));
        rightWing.addChild("right_wing_tip", ModelPartBuilder.create()
                        .uv(24, 100).cuboid(-1.0F, 0.0F, 0.0F, 2.0F, 18.0F, 1.0F),
                ModelTransform.pivot(1.0F, 19.0F, 0.0F));

        ModelPartData leftLeg = root.addChild("left_leg", ModelPartBuilder.create()
                        .uv(96, 0).cuboid(-4.0F, 0.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                        .uv(96, 20).cuboid(-4.5F, 8.0F, -5.0F, 9.0F, 4.0F, 11.0F),
                ModelTransform.pivot(-4.5F, 5.0F, 0.0F));
        ModelPartData rightLeg = root.addChild("right_leg", ModelPartBuilder.create()
                        .uv(96, 0).cuboid(-4.0F, 0.0F, -4.0F, 8.0F, 11.0F, 8.0F)
                        .uv(96, 20).cuboid(-4.5F, 8.0F, -5.0F, 9.0F, 4.0F, 11.0F),
                ModelTransform.pivot(4.5F, 5.0F, 0.0F));

        root.addChild("tail", ModelPartBuilder.create()
                        .uv(80, 40).cuboid(-3.0F, -1.5F, 0.0F, 6.0F, 5.0F, 12.0F)
                        .uv(80, 58).cuboid(-2.0F, 0.0F, 10.0F, 4.0F, 3.0F, 10.0F)
                        .uv(80, 72).cuboid(-1.0F, 0.5F, 18.0F, 2.0F, 2.0F, 6.0F),
                ModelTransform.pivot(0.0F, -1.0F, 5.0F));

        return TexturedModelData.of(data, 128, 128);
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    @Override
    public void setAngles(AbyssalColossusEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        this.head.yaw = headYaw * 0.017453292F;
        this.head.pitch = headPitch * 0.017453292F;
        this.leftHead.yaw = -0.12F + headYaw * 0.008F;
        this.rightHead.yaw = 0.12F + headYaw * 0.008F;
        this.leftHead.pitch = MathHelper.sin(animationProgress * 0.055F) * 0.045F;
        this.rightHead.pitch = -this.leftHead.pitch;

        boolean sprinting = entity.isSprinting() || limbDistance > 0.72F;
        float stride = sprinting ? 1.48F : 1.0F;
        float amount = Math.min(limbDistance, 1.25F);
        float cycle = limbAngle * (sprinting ? 0.92F : 0.72F);
        this.leftLeg.pitch = MathHelper.cos(cycle) * 1.15F * amount * stride;
        this.rightLeg.pitch = MathHelper.cos(cycle + (float) Math.PI) * 1.15F * amount * stride;
        this.leftArm.pitch = -MathHelper.cos(cycle) * 0.72F * amount - 0.12F;
        this.rightArm.pitch = -MathHelper.cos(cycle + (float) Math.PI) * 0.72F * amount - 0.12F;

        float flap = MathHelper.sin(animationProgress * 0.105F) * 0.18F;
        this.leftWing.roll = -0.22F - flap;
        this.rightWing.roll = 0.22F + flap;
        this.leftWing.pitch = 0.10F + MathHelper.cos(animationProgress * 0.08F) * 0.07F;
        this.rightWing.pitch = this.leftWing.pitch;
        this.tail.yaw = MathHelper.sin(animationProgress * 0.045F) * 0.18F;
        this.tail.pitch = 0.08F + MathHelper.sin(animationProgress * 0.07F) * 0.04F;

        if (entity.isAttacking()) {
            float punch = MathHelper.sin(animationProgress * 0.9F) * 0.18F;
            this.rightArm.pitch = -2.45F + punch;
            this.leftArm.pitch = -0.72F;
            this.torso.roll = -0.08F;
        } else {
            this.torso.roll = 0.0F;
        }

        if (sprinting) {
            this.leftWing.roll = -0.42F - flap;
            this.rightWing.roll = 0.42F + flap;
            this.torso.pitch = 0.06F;
        } else {
            this.torso.pitch = MathHelper.sin(animationProgress * 0.045F) * 0.025F;
        }
    }
}
