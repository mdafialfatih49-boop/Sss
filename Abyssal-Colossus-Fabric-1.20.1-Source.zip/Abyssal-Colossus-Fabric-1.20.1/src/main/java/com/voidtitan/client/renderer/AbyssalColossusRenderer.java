package com.voidtitan.client.renderer;

import com.voidtitan.VoidTitan;
import com.voidtitan.client.VoidTitanClient;
import com.voidtitan.client.model.AbyssalColossusModel;
import com.voidtitan.entity.AbyssalColossusEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class AbyssalColossusRenderer extends MobEntityRenderer<AbyssalColossusEntity, AbyssalColossusModel> {
    private static final Identifier TEXTURE = new Identifier(
            VoidTitan.MOD_ID, "textures/entity/abyssal_colossus.png"
    );

    public AbyssalColossusRenderer(EntityRendererFactory.Context context) {
        super(context, new AbyssalColossusModel(
                context.getPart(VoidTitanClient.ABYSSAL_COLOSSUS_LAYER)
        ), 1.35F);
    }

    @Override
    public Identifier getTexture(AbyssalColossusEntity entity) {
        return TEXTURE;
    }
}
