# Abyssal Colossus — Fabric 1.20.1

A powerful 3-block-tall boss inspired by the creature in the supplied reference image. Its design combines a Warden-like sculk body and glowing core, three Wither-like heads, and Ender Dragon-style wings.

## Features

- **Abyssal Colossus:** 520 health, 22 armor, 14 armor toughness, 28 base melee damage, very high knockback resistance, and a 3.05-block hitbox height.
- **Boss bar:** purple health bar appears for players tracking the boss.
- **Resonance Wave:** a cyan sculk ring that damages, slows, and pushes nearby creatures.
- **Triple Wither Burst:** three streams of soul fire that damage the target and apply Wither.
- **Dragon Wing Crash:** a wide non-destructive shockwave that damages and launches nearby creatures.
- **Void Step:** a short Ender-style teleport to reposition behind a distant target.
- **Animations:** procedural walk, sprint, punch, idle head motion, tail sway, and wing flap animations in the Java model.
- **Spawn egg:** included in the vanilla Spawn Eggs creative tab.
- **Blockbench source:** `blockbench/abyssal_colossus.bbmodel` and its texture are included for editing.

## Requirements

- Minecraft Java Edition **1.20.1**
- Fabric Loader **0.15.0 or newer**
- Fabric API for Minecraft 1.20.1
- Java **17**

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this source project to the repository root (the `.github` folder must remain included).
3. Push to `main` or `master`, or open **Actions → Build Abyssal Colossus Mod → Run workflow**.
4. When the workflow finishes, open its run and download the artifact named `Abyssal-Colossus-Fabric-1.20.1`.
5. Put the built mod JAR in the `mods` folder together with Fabric API.

The workflow uses Java 17 and Gradle 8.8. The build output is placed in `build/libs/`.

## Local build

Install JDK 17 and Gradle 8.8, open a terminal in the project root, and run:

```bash
gradle build
```

## Spawn the boss

Use the spawn egg from the Spawn Eggs creative tab, or run:

```mcfunction
/summon voidtitan:abyssal_colossus
```

The boss is intentionally not added to natural world spawning, so it will not unexpectedly appear in ordinary survival exploration.

## Blockbench notes

Open `blockbench/abyssal_colossus.bbmodel` in Blockbench. The Java renderer is the in-game source of truth for runtime geometry and procedural animation. If you change cube geometry in Blockbench, transfer those changes into `AbyssalColossusModel.java`; the `.bbmodel` file is supplied as an editable design source and is not automatically compiled by Gradle.

## Project layout

- `src/main/java/` — entity AI, abilities, registration, model and renderer
- `src/main/resources/` — Fabric metadata, language, texture, spawn-egg item model and loot table
- `blockbench/` — editable Blockbench model source and texture
- `.github/workflows/build.yml` — GitHub Actions build workflow
