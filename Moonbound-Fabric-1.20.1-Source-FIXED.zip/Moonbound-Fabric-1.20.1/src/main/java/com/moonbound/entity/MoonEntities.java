package com.moonbound.entity;

import com.moonbound.MoonboundMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class MoonEntities {
    public static final EntityType<MoonWalkerEntity> MOON_WALKER = Registry.register(
            Registries.ENTITY_TYPE,
            MoonboundMod.id("moon_walker"),
            EntityType.Builder.create(MoonWalkerEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6f, 1.95f)
                    .build("moon_walker")
    );

    public static final EntityType<MoonSlimeEntity> MOON_SLIME = Registry.register(
            Registries.ENTITY_TYPE,
            MoonboundMod.id("moon_slime"),
            EntityType.Builder.create(MoonSlimeEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(1.2f, 1.2f)
                    .build("moon_slime")
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(MOON_WALKER, ZombieEntity.createZombieAttributes());
        FabricDefaultAttributeRegistry.register(MOON_SLIME, MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 18.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.22)
                .build());
        MoonboundMod.LOGGER.info("Registering Moonbound entities");
    }

    private MoonEntities() {}
}
