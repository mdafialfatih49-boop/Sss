# Zeus Boss — Fabric 1.20.1

Mod Minecraft Java Edition yang menambahkan boss Zeus dengan tampilan humanoid bergaya Minecraft, terinspirasi dari gambar referensi yang diberikan.

## Fitur

- **500 HP** dan boss bar berwarna **hijau**.
- Serangan jarak dekat dengan attack damage **34**.
- Movement speed **0.34**, armor **24**, armor toughness **12**, dan knockback resistance **100%**.
- Zeus mengangkat tangan selama animasi charge, lalu memanggil petir ke target.
- Saat Zeus pertama kali muncul, pemain dalam radius 64 blok menerima teks merah **⚡ZEUS IS HERE⚡**.
- Serangan proyektil yang mengenai Zeus ditangkis/dibelokkan kembali, termasuk panah dan snowball, disertai partikel tebasan dan percikan listrik.
- Spawn egg, icon mod, tekstur UV 64×64, dan terjemahan Indonesia/Inggris.

## Versi dan dependensi

- Minecraft Java **1.20.1**
- Fabric Loader **0.15.11 atau lebih baru**
- Fabric API **0.92.2+1.20.1**
- Java **17**
- Gradle **8.8**

## Cara memanggil Zeus

Gunakan spawn egg **Telur Panggil Boss Zeus**, atau jalankan perintah:

```mcfunction
/summon zeusboss:zeus_boss
```

ID item spawn egg:

```text
zeusboss:zeus_boss_spawn_egg
```

## Build menjadi JAR

Dari folder proyek, jalankan:

```bash
gradle build
```

JAR hasil build ada di `build/libs/zeusboss-fabric-1.20.1-1.0.0.jar`.

Untuk pengguna GitHub Actions, gunakan file workflow `ZeusBoss-Build.yml` yang dibagikan bersama ZIP. Simpan ZIP ini di root repository dengan nama `ZeusBoss-Fabric-1.20.1-Source.zip`, lalu simpan workflow pada `.github/workflows/build.yml`.

## Catatan

Proyek ini disiapkan sebagai **source project** untuk Fabric 1.20.1. Build JAR tidak dijalankan di lingkungan pembuatan file ini karena Gradle/dependensi tidak tersedia secara lokal; workflow GitHub Actions disediakan untuk melakukan build di runner GitHub.
