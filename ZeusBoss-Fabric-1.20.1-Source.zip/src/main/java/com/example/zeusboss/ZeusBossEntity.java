package com.example.zeusboss;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ZeusBossEntity extends HostileEntity {
    private static final TrackedData<Boolean> CASTING = DataTracker.registerData(
            ZeusBossEntity.class, TrackedDataHandlerRegistry.BOOLEAN
    );

    private final ServerBossBar bossBar = new ServerBossBar(
            net.minecraft.text.Text.literal("⚡ ZEUS ⚡"), BossBar.Color.GREEN, BossBar.Style.PROGRESS
    );

    private int lightningCooldown = 70;
    private int lightningWindup = 0;
    private boolean announced = false;

    public ZeusBossEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.experiencePoints = 100;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 500.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 34.0D)
                .add(EntityAttributes.GENERIC_ARMOR, 24.0D)
                .add(EntityAttributes.GENERIC_ARMOR_TOUGHNESS, 12.0D)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8D));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 18.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(CASTING, false);
    }

    public boolean isCastingLightning() {
        return this.dataTracker.get(CASTING);
    }

    private void setCastingLightning(boolean casting) {
        this.dataTracker.set(CASTING, casting);
    }

    @Override
    public void tick() {
        super.tick();

        if (this.getWorld().isClient()) {
            return;
        }

        if (this.getWorld() instanceof ServerWorld serverWorld) {
            if (!this.announced) {
                this.announced = true;
                for (ServerPlayerEntity player : serverWorld.getPlayers()) {
                    if (player.squaredDistanceTo(this) <= 64.0D * 64.0D) {
                        ServerPlayNetworking.send(player, ZeusBossMod.ANNOUNCE_PACKET, PacketByteBufs.empty());
                    }
                }
            }
        }

        this.bossBar.setPercent(MathHelper.clamp(this.getHealth() / this.getMaxHealth(), 0.0F, 1.0F));

        if (this.lightningCooldown > 0) {
            this.lightningCooldown--;
        }

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            this.lightningWindup = 0;
            this.setCastingLightning(false);
            return;
        }

        if (this.lightningWindup > 0) {
            this.lightningWindup--;
            this.setCastingLightning(true);
            this.getNavigation().stop();
            this.getLookControl().lookAt(target, 30.0F, 30.0F);

            if (this.lightningWindup == 0 && this.getWorld() instanceof ServerWorld serverWorld) {
                this.strikeLightning(serverWorld, target);
                this.lightningCooldown = 105;
                this.setCastingLightning(false);
            }
        } else {
            this.setCastingLightning(false);
            if (this.lightningCooldown <= 0
                    && this.squaredDistanceTo(target) <= 24.0D * 24.0D
                    && this.canSee(target)) {
                this.lightningWindup = 28;
                this.setCastingLightning(true);
            }
        }
    }

    private void strikeLightning(ServerWorld world, LivingEntity target) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(target.getX(), target.getY(), target.getZ());
            world.spawnEntity(bolt);
        }

        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                target.getX(), target.getY() + 1.0D, target.getZ(),
                24, 0.45D, 0.7D, 0.45D, 0.08D);
        this.playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 3.5F, 0.9F);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.getSource() instanceof ProjectileEntity projectile) {
            if (!this.getWorld().isClient() && this.getWorld() instanceof ServerWorld serverWorld
                    && projectile.getOwner() != this) {
                this.deflectProjectile(serverWorld, projectile);
            }
            return false;
        }
        return super.damage(source, amount);
    }

    public void deflectProjectileFromCollision(ProjectileEntity projectile) {
        if (!this.getWorld().isClient() && this.getWorld() instanceof ServerWorld serverWorld
                && projectile.getOwner() != this) {
            this.deflectProjectile(serverWorld, projectile);
        }
    }

    private void deflectProjectile(ServerWorld world, ProjectileEntity projectile) {
        Vec3d incoming = projectile.getVelocity();
        Vec3d away = projectile.getPos().subtract(this.getPos());
        if (away.lengthSquared() < 0.0001D) {
            away = new Vec3d(0.0D, 0.0D, 1.0D);
        }
        away = away.normalize().multiply(0.65D);

        projectile.setVelocity(
                -incoming.x + away.x,
                Math.max(0.18D, incoming.y),
                -incoming.z + away.z
        );
        projectile.setOwner(this);

        double particleY = this.getY() + this.getHeight() * 0.55D;
        world.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                this.getX(), particleY, this.getZ(), 1,
                0.55D, 0.45D, 0.55D, 0.0D);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                this.getX(), particleY, this.getZ(), 10,
                0.45D, 0.45D, 0.45D, 0.06D);
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("ZeusAnnounced", this.announced);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.announced = nbt.getBoolean("ZeusAnnounced");
    }
}
