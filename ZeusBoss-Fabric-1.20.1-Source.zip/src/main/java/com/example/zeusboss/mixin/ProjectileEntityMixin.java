package com.example.zeusboss.mixin;

import com.example.zeusboss.ZeusBossEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ProjectileEntity.class)
public abstract class ProjectileEntityMixin {
    @Inject(method = "onCollision", at = @At("HEAD"), cancellable = true)
    private void zeusboss$reflectFromZeus(HitResult hitResult, CallbackInfo callbackInfo) {
        if (hitResult instanceof EntityHitResult entityHitResult
                && entityHitResult.getEntity() instanceof ZeusBossEntity zeus) {
            ProjectileEntity projectile = (ProjectileEntity) (Object) this;
            if (projectile.getOwner() != zeus) {
                zeus.deflectProjectileFromCollision(projectile);
                callbackInfo.cancel();
            }
        }
    }
}
