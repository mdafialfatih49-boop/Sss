package com.example.zeusboss;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item ZEUS_BOSS_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            new Identifier(ZeusBossMod.MOD_ID, "zeus_boss_spawn_egg"),
            new SpawnEggItem(ModEntities.ZEUS_BOSS, 0xB77E64, 0xF4C928, new Item.Settings())
    );

    private ModItems() {
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(ZEUS_BOSS_SPAWN_EGG));
        ZeusBossMod.LOGGER.info("Registering Zeus Boss spawn egg");
    }
}
