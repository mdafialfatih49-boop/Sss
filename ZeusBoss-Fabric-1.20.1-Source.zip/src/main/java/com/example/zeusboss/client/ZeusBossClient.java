package com.example.zeusboss.client;

import com.example.zeusboss.ModEntities;
import com.example.zeusboss.ZeusBossMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ZeusBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.ZEUS_BOSS,
                context -> new ZeusBossRenderer(context));

        ZeusBossHud.register();

        ClientPlayNetworking.registerGlobalReceiver(ZeusBossMod.ANNOUNCE_PACKET,
                (client, handler, buf, responseSender) -> client.execute(ZeusBossHud::show));
    }
}
