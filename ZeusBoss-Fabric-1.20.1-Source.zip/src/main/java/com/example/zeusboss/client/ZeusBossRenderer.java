package com.example.zeusboss.client;

import com.example.zeusboss.ZeusBossEntity;
import com.example.zeusboss.ZeusBossMod;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;

public class ZeusBossRenderer extends BipedEntityRenderer<ZeusBossEntity, ZeusBossModel> {
    private static final Identifier TEXTURE = new Identifier(ZeusBossMod.MOD_ID,
            "textures/entity/zeus.png");

    public ZeusBossRenderer(EntityRendererFactory.Context context) {
        super(context, new ZeusBossModel(context.getPart(EntityModelLayers.PLAYER)), 0.55F);
    }

    @Override
    public Identifier getTexture(ZeusBossEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ZeusBossEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.28F, 1.28F, 1.28F);
    }
}
