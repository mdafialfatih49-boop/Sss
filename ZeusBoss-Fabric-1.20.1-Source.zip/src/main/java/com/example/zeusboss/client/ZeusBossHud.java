package com.example.zeusboss.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class ZeusBossHud {
    private static int ticksRemaining = 0;

    private ZeusBossHud() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (ticksRemaining > 0) {
                ticksRemaining--;
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (ticksRemaining <= 0) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            Text message = Text.literal("⚡ZEUS IS HERE⚡")
                    .formatted(Formatting.RED, Formatting.BOLD);
            int x = client.getWindow().getScaledWidth() / 2;
            int y = client.getWindow().getScaledHeight() / 4;
            drawContext.drawCenteredTextWithShadow(client.textRenderer, message, x, y, 0xFFFF2222);
        });
    }

    public static void show() {
        ticksRemaining = 100;
    }
}
