package com.example.zeusboss.client;

import com.example.zeusboss.ZeusBossEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;

public class ZeusBossModel extends BipedEntityModel<ZeusBossEntity> {
    public ZeusBossModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setAngles(ZeusBossEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        if (entity.isCastingLightning()) {
            this.rightArm.pitch = -2.85F;
            this.rightArm.yaw = -0.18F;
            this.rightArm.roll = -0.12F;
            this.leftArm.pitch = -0.25F;
        }
    }
}
