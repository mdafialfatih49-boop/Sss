package com.example.zeusboss;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZeusBossMod implements ModInitializer {
    public static final String MOD_ID = "zeusboss";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final Identifier ANNOUNCE_PACKET = new Identifier(MOD_ID, "announce_zeus");

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
        FabricDefaultAttributeRegistry.register(ModEntities.ZEUS_BOSS, ZeusBossEntity.createAttributes());
        LOGGER.info("Zeus Boss mod loaded. Let the storm begin!");
    }
}
