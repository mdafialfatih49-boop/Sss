package com.example.zeusboss;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final EntityType<ZeusBossEntity> ZEUS_BOSS = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(ZeusBossMod.MOD_ID, "zeus_boss"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ZeusBossEntity::new)
                    .dimensions(EntityDimensions.fixed(1.05F, 2.75F))
                    .trackRangeBlocks(12)
                    .trackedUpdateRate(2)
                    .build()
    );

    private ModEntities() {
    }

    public static void register() {
        ZeusBossMod.LOGGER.info("Registering Zeus Boss entity");
    }
}
