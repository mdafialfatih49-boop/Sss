package com.crowley.mod;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;

public class CrowleyEntity extends HostileEntity {
    private static final TrackedData<Integer> ANIMATION_MODE = DataTracker.registerData(CrowleyEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ANIMATION_TICKS = DataTracker.registerData(CrowleyEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ROAR_TICKS = DataTracker.registerData(CrowleyEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> SLAM_TARGET_ID = DataTracker.registerData(CrowleyEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private int roarCooldown = 80;
    private int slamCooldown = 0;
    private int slamProgress = 0;
    private LivingEntity grabbedTarget;
    private final ServerBossBar bossBar = new ServerBossBar(Text.literal("The Crowley"), BossBar.Color.RED, BossBar.Style.PROGRESS);

    public CrowleyEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.experiencePoints = 35;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createCrowleyAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 650.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.31D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 46.0D)
                .add(EntityAttributes.GENERIC_ARMOR, 28.0D)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.12D, true));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 18.0F));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, MobEntity.class, 10, true, false,
                target -> target != this && !(target instanceof CrowleyEntity)));
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(ANIMATION_MODE, 0);
        this.dataTracker.startTracking(ANIMATION_TICKS, 0);
        this.dataTracker.startTracking(ROAR_TICKS, 0);
        this.dataTracker.startTracking(SLAM_TARGET_ID, -1);
    }

    public int getAnimationMode() {
        return this.dataTracker.get(ANIMATION_MODE);
    }

    public int getAnimationTicks() {
        return this.dataTracker.get(ANIMATION_TICKS);
    }

    public int getRoarTicks() {
        return this.dataTracker.get(ROAR_TICKS);
    }

    public int getSlamTargetId() {
        return this.dataTracker.get(SLAM_TARGET_ID);
    }

    private void setAnimation(int mode, int ticks) {
        this.dataTracker.set(ANIMATION_MODE, mode);
        this.dataTracker.set(ANIMATION_TICKS, ticks);
    }

    private void roar() {
        this.dataTracker.set(ROAR_TICKS, 38);
        this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR,
                SoundCategory.HOSTILE, 3.2F, 0.68F);
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 2.2D, this.getZ(),
                    22, 1.1D, 0.7D, 1.1D, 0.08D);
            serverWorld.spawnParticles(ParticleTypes.ASH, this.getX(), this.getY() + 2.0D, this.getZ(),
                    16, 0.9D, 0.7D, 0.9D, 0.02D);
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (this.getWorld().isClient) {
            return;
        }

        if (this.age % 5 == 0) {
            this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        }

        if (this.getAnimationTicks() > 0) {
            this.dataTracker.set(ANIMATION_TICKS, this.getAnimationTicks() - 1);
        } else if (this.getAnimationMode() != 0) {
            this.dataTracker.set(ANIMATION_MODE, 0);
        }

        if (this.getRoarTicks() > 0) {
            this.dataTracker.set(ROAR_TICKS, this.getRoarTicks() - 1);
        }

        if (this.roarCooldown > 0) {
            this.roarCooldown--;
        }
        if (this.slamCooldown > 0) {
            this.slamCooldown--;
        }

        LivingEntity currentTarget = this.getTarget();
        if (currentTarget != null && currentTarget.isAlive()) {
            double distance = this.squaredDistanceTo(currentTarget);
            if (this.roarCooldown <= 0 && distance > 36.0D && distance < 625.0D) {
                this.roar();
                this.roarCooldown = 240;
            }

            if (this.grabbedTarget == null && this.slamCooldown <= 0 && distance < 9.0D
                    && this.getAnimationMode() != 2) {
                this.beginSlam(currentTarget);
            }
        }

        if (this.grabbedTarget != null) {
            this.tickSlam();
        }
    }

    private void beginSlam(LivingEntity target) {
        this.grabbedTarget = target;
        this.slamProgress = 0;
        this.slamCooldown = 170;
        this.dataTracker.set(SLAM_TARGET_ID, target.getId());
        this.dataTracker.set(ANIMATION_MODE, 2);
        this.dataTracker.set(ANIMATION_TICKS, 30);
        this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_ATTACK,
                SoundCategory.HOSTILE, 2.4F, 0.6F);
    }

    private void tickSlam() {
        if (this.grabbedTarget == null || !this.grabbedTarget.isAlive()) {
            this.finishSlam();
            return;
        }

        this.slamProgress++;
        LivingEntity victim = this.grabbedTarget;
        float yawRadians = this.getYaw() * ((float) Math.PI / 180.0F);
        double holdX = this.getX() - MathHelper.sin(yawRadians) * 1.65D;
        double holdZ = this.getZ() + MathHelper.cos(yawRadians) * 1.65D;

        if (this.slamProgress <= 17) {
            victim.setVelocity(Vec3d.ZERO);
            victim.fallDistance = 0.0F;
            victim.requestTeleport(holdX, this.getY() + 1.65D, holdZ);
        } else if (this.slamProgress == 18) {
            victim.damage(this.getDamageSources().mobAttack(this), 2000.0F);
            if (victim.isAlive()) {
                victim.setHealth(0.0F);
            }
            this.dataTracker.set(ROAR_TICKS, 13);
            this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE,
                    SoundCategory.HOSTILE, 2.2F, 0.72F);
            if (this.getWorld() instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                        holdX, this.getY() + 0.15D, holdZ, 18, 0.55D, 0.12D, 0.55D, 0.12D);
                serverWorld.spawnParticles(ParticleTypes.CLOUD,
                        holdX, this.getY() + 0.2D, holdZ, 20, 0.75D, 0.18D, 0.75D, 0.08D);
                serverWorld.spawnParticles(ParticleTypes.CRIT,
                        holdX, this.getY() + 0.3D, holdZ, 12, 0.45D, 0.25D, 0.45D, 0.12D);
            }
        }

        if (this.slamProgress >= 30) {
            this.finishSlam();
        }
    }

    private void finishSlam() {
        this.grabbedTarget = null;
        this.slamProgress = 0;
        this.dataTracker.set(SLAM_TARGET_ID, -1);
        if (this.getAnimationTicks() <= 0) {
            this.dataTracker.set(ANIMATION_MODE, 0);
        }
    }

    @Override
    public boolean tryAttack(Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return false;
        }
        boolean damaged = livingTarget.damage(this.getDamageSources().mobAttack(this), 46.0F);
        if (damaged) {
            double dx = this.getX() - livingTarget.getX();
            double dz = this.getZ() - livingTarget.getZ();
            livingTarget.takeKnockback(2.65D, dx, dz);
            livingTarget.addVelocity(0.0D, 0.62D, 0.0D);
            this.setAnimation(1, 16);
            this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_ATTACK,
                    SoundCategory.HOSTILE, 2.0F, 0.72F);
            if (this.getWorld() instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(ParticleTypes.CRIT,
                        livingTarget.getX(), livingTarget.getBodyY(0.55D), livingTarget.getZ(),
                        8, 0.35D, 0.3D, 0.35D, 0.1D);
            }
        }
        return damaged;
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WARDEN_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 2.0F;
    }
}
