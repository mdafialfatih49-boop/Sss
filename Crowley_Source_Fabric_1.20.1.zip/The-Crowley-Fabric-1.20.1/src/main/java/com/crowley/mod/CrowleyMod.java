package com.crowley.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class CrowleyMod implements ModInitializer {
    public static final String MOD_ID = "crowley";

    public static final EntityType<CrowleyEntity> THE_CROWLEY = Registry.register(
            Registries.ENTITY_TYPE,
            id("the_crowley"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, CrowleyEntity::new)
                    .dimensions(EntityDimensions.fixed(2.8F, 5.8F))
                    .trackRangeBlocks(24)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final Item CROWLEY_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            id("the_crowley_spawn_egg"),
            new SpawnEggItem(THE_CROWLEY, 0x171717, 0x7B1824, new Item.Settings())
    );

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(THE_CROWLEY, CrowleyEntity.createCrowleyAttributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(CROWLEY_SPAWN_EGG));
    }
}
