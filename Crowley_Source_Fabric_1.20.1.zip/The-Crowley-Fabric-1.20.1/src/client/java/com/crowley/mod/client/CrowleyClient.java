package com.crowley.mod.client;

import com.crowley.mod.CrowleyEntity;
import com.crowley.mod.CrowleyMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3f;

public class CrowleyClient implements ClientModInitializer {
    public static final EntityModelLayer MODEL_LAYER = new EntityModelLayer(CrowleyMod.id("the_crowley"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(MODEL_LAYER, CrowleyModel::getTexturedModelData);
        EntityRendererRegistry.register(CrowleyMod.THE_CROWLEY, CrowleyRenderer::new);

        // The tracked roar timer is synchronized by Minecraft, so every nearby client gets the shake.
        WorldRenderEvents.START.register(context -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world == null || client.player == null || context.matrixStack() == null) {
                return;
            }
            CrowleyEntity crowley = client.world.getEntitiesByClass(CrowleyEntity.class,
                    client.player.getBoundingBox().expand(32.0D), entity -> entity.getRoarTicks() > 0)
                    .stream().findFirst().orElse(null);
            if (crowley == null) {
                return;
            }
            float strength = Math.min(1.0F, crowley.getRoarTicks() / 18.0F);
            float time = client.world.getTime() + context.tickDelta();
            float roll = MathHelper.sin(time * 1.65F) * 1.8F * strength;
            float pitch = MathHelper.cos(time * 1.9F) * 1.2F * strength;
            context.matrixStack().multiply(Vec3f.POSITIVE_Z.getDegreesQuaternion(roll));
            context.matrixStack().multiply(Vec3f.POSITIVE_X.getDegreesQuaternion(pitch));
        });
    }
}
