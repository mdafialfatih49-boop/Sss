package com.crowley.mod.client;

import com.crowley.mod.CrowleyEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class CrowleyModel extends SinglePartEntityModel<CrowleyEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public CrowleyModel(ModelPart root) {
        super();
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        root.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-11.0F, -17.0F, -9.0F, 22.0F, 21.0F, 18.0F)
                        .uv(0, 64).cuboid(-10.0F, -4.0F, -11.0F, 20.0F, 8.0F, 4.0F),
                ModelTransform.pivot(0.0F, -34.0F, 0.0F));

        root.addChild("body", ModelPartBuilder.create()
                        .uv(0, 86).cuboid(-14.0F, -30.0F, -8.0F, 28.0F, 34.0F, 16.0F)
                        .uv(0, 174).cuboid(-12.0F, -2.0F, -9.0F, 24.0F, 5.0F, 18.0F),
                ModelTransform.pivot(0.0F, -5.0F, 0.0F));

        root.addChild("left_arm", ModelPartBuilder.create()
                        .uv(96, 0).cuboid(-6.0F, -3.0F, -6.0F, 12.0F, 38.0F, 12.0F),
                ModelTransform.pivot(19.0F, -28.0F, 0.0F));
        root.addChild("right_arm", ModelPartBuilder.create()
                        .uv(160, 0).cuboid(-6.0F, -3.0F, -6.0F, 12.0F, 38.0F, 12.0F),
                ModelTransform.pivot(-19.0F, -28.0F, 0.0F));

        root.addChild("left_leg", ModelPartBuilder.create()
                        .uv(96, 94).cuboid(-7.0F, -1.0F, -7.0F, 14.0F, 36.0F, 14.0F),
                ModelTransform.pivot(8.0F, 0.0F, 0.0F));
        root.addChild("right_leg", ModelPartBuilder.create()
                        .uv(168, 94).cuboid(-7.0F, -1.0F, -7.0F, 14.0F, 36.0F, 14.0F),
                ModelTransform.pivot(-8.0F, 0.0F, 0.0F));

        return TexturedModelData.of(data, 256, 256);
    }

    @Override
    public void setAngles(CrowleyEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        this.head.yaw = headYaw * 0.017453292F;
        this.head.pitch = headPitch * 0.017453292F;
        this.body.yaw = 0.0F;

        float walk = MathHelper.cos(limbAngle * 0.55F) * 0.72F * limbDistance;
        this.rightLeg.pitch = walk;
        this.leftLeg.pitch = -walk;
        this.rightArm.pitch = -walk * 0.7F;
        this.leftArm.pitch = walk * 0.7F;
        this.leftArm.roll = 0.0F;
        this.rightArm.roll = 0.0F;

        int mode = entity.getAnimationMode();
        int ticks = entity.getAnimationTicks();
        if (mode == 1) {
            float swing = (16.0F - ticks) / 16.0F;
            this.rightArm.pitch = -2.6F + swing * 3.4F;
            this.rightArm.roll = -0.18F;
            this.body.yaw = -0.12F;
        } else if (mode == 2) {
            if (ticks > 14) {
                this.leftArm.pitch = -2.75F;
                this.rightArm.pitch = -2.75F;
                this.leftArm.roll = 0.22F;
                this.rightArm.roll = -0.22F;
                this.body.pitch = -0.08F;
            } else {
                this.leftArm.pitch = 1.55F;
                this.rightArm.pitch = 1.55F;
                this.leftArm.roll = 0.10F;
                this.rightArm.roll = -0.10F;
                this.body.pitch = 0.18F;
            }
        } else {
            this.body.pitch = 0.0F;
        }

        if (entity.getRoarTicks() > 0) {
            float roarStrength = Math.min(1.0F, entity.getRoarTicks() / 18.0F);
            this.head.pitch = -0.45F * roarStrength;
            this.head.roll = MathHelper.sin(animationProgress * 0.8F) * 0.08F * roarStrength;
        } else {
            this.head.roll = 0.0F;
        }
    }
}
