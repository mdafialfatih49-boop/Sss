package com.crowley.mod.client;

import com.crowley.mod.CrowleyEntity;
import com.crowley.mod.CrowleyMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class CrowleyRenderer extends MobEntityRenderer<CrowleyEntity, CrowleyModel> {
    private static final Identifier TEXTURE = CrowleyMod.id("textures/entity/the_crowley.png");

    public CrowleyRenderer(EntityRendererFactory.Context context) {
        super(context, new CrowleyModel(context.getPart(CrowleyClient.MODEL_LAYER)), 1.55F);
    }

    @Override
    public Identifier getTexture(CrowleyEntity entity) {
        return TEXTURE;
    }
}
