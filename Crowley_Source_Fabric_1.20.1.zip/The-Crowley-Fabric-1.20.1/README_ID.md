# The Crowley — Fabric 1.20.1

Mod boss monster untuk Minecraft Java Edition 1.20.1 + Fabric.

## Fitur
- Tinggi hitbox 5,8 blok dan lebar 2,8 blok.
- 650 HP (lebih tinggi dari Warden), 28 armor, dan knockback resistance penuh.
- Menargetkan berbagai mob vanilla, baik pasif maupun monster lain; tidak menargetkan pemain.
- Pukulan 46 damage dengan dorongan kuat.
- Serangan khusus: mencengkeram mob, mengangkatnya, lalu membantingnya. Target menerima damage sangat besar dan efek partikel merah bergaya blok Minecraft.
- Auman Warden-style dengan partikel debu/awan dan getaran kamera untuk pemain di sekitar.
- Model besar dengan animasi jalan, pukulan, auman, dan bantingan.
- Spawn egg tersedia di tab Spawn Eggs.

## Cara memanggil
```mcfunction
/summon crowley:the_crowley ~ ~ ~
/give @s crowley:the_crowley_spawn_egg
```

## Build
Gunakan Java 17 dan Gradle 8.8:
```bash
gradle build
```
JAR hasil build yang dipakai ada di `build/libs/` (file tanpa akhiran `-dev`).

## Catatan
Efek merah memakai partikel blok redstone sebagai efek visual bergaya Minecraft, bukan gore. Mod ini menargetkan mob non-player; pemain tidak dijadikan target otomatis.
