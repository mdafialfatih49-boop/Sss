package com.gigantoapes;

import com.gigantoapes.entity.ApeEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.BiomeKeys;

public class GigantoApes implements ModInitializer {
    public static final String MOD_ID = "gigantoapes";

    public static final EntityType<ApeEntity> GIGANTOPITHECUS = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MOD_ID, "gigantopithecus"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, ApeEntity::new)
                    .dimensions(EntityDimensions.fixed(2.0f, 3.4f)).trackRangeBlocks(10).build());

    public static final EntityType<ApeEntity> GORUTAN = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MOD_ID, "gorutan"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, ApeEntity::new)
                    .dimensions(EntityDimensions.fixed(1.4f, 2.2f)).trackRangeBlocks(10).build());

    public static final Item GIGANTOPITHECUS_SPAWN_EGG = Registry.register(Registries.ITEM,
            new Identifier(MOD_ID, "gigantopithecus_spawn_egg"),
            new SpawnEggItem(GIGANTOPITHECUS, 0x4A3A2E, 0xA88B6A, new FabricItemSettings()));

    public static final Item GORUTAN_SPAWN_EGG = Registry.register(Registries.ITEM,
            new Identifier(MOD_ID, "gorutan_spawn_egg"),
            new SpawnEggItem(GORUTAN, 0x3A3A40, 0xC25E20, new FabricItemSettings()));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(GIGANTOPITHECUS, ApeEntity.createGigantoAttributes());
        FabricDefaultAttributeRegistry.register(GORUTAN, ApeEntity.createGorutanAttributes());

        SpawnRestriction.register(GIGANTOPITHECUS, SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, ApeEntity::canSpawnAt);
        SpawnRestriction.register(GORUTAN, SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, ApeEntity::canSpawnAt);

        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.BAMBOO_JUNGLE, BiomeKeys.JUNGLE),
                SpawnGroup.CREATURE, GIGANTOPITHECUS, 4, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_JUNGLE),
                SpawnGroup.CREATURE, GORUTAN, 10, 1, 3);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(GIGANTOPITHECUS_SPAWN_EGG);
            entries.add(GORUTAN_SPAWN_EGG);
        });
    }
}
