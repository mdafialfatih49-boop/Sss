package com.gigantoapes.client;

import com.gigantoapes.GigantoApes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class GigantoApesClient implements ClientModInitializer {
    public static final EntityModelLayer GIGANTO_LAYER =
            new EntityModelLayer(new Identifier(GigantoApes.MOD_ID, "gigantopithecus"), "main");
    public static final EntityModelLayer GORUTAN_LAYER =
            new EntityModelLayer(new Identifier(GigantoApes.MOD_ID, "gorutan"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(GIGANTO_LAYER, () -> ApeModel.createData(false));
        EntityModelLayerRegistry.registerModelLayer(GORUTAN_LAYER, () -> ApeModel.createData(true));

        Identifier gTex = new Identifier(GigantoApes.MOD_ID, "textures/entity/gigantopithecus.png");
        Identifier rTex = new Identifier(GigantoApes.MOD_ID, "textures/entity/gorutan.png");

        EntityRendererRegistry.register(GigantoApes.GIGANTOPITHECUS,
                ctx -> new ApeRenderer(ctx, GIGANTO_LAYER, gTex, 2.2f, 1.6f));
        EntityRendererRegistry.register(GigantoApes.GORUTAN,
                ctx -> new ApeRenderer(ctx, GORUTAN_LAYER, rTex, 1.45f, 1.0f));
    }
}
