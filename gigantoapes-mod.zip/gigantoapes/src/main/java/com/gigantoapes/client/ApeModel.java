package com.gigantoapes.client;

import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public class ApeModel<T extends LivingEntity> extends EntityModel<T> {
    private final ModelPart root, head, body, rightArm, leftArm, rightLeg, leftLeg;
    private static final float BODY_TILT = 0.35f;

    public ApeModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    /** hybrid=false: Gigantopithecus (alis tebal). hybrid=true: Gorutan (pipi orangutan). */
    public static TexturedModelData createData(boolean hybrid) {
        ModelData data = new ModelData();
        ModelPartData rt = data.getRoot();

        ModelPartData headData = rt.addChild("head",
                ModelPartBuilder.create().uv(0, 0).cuboid(-4, -8, -4, 8, 8, 8),
                ModelTransform.pivot(0, 8, -5));
        headData.addChild("muzzle",
                ModelPartBuilder.create().uv(32, 0).cuboid(-2, -3, -6, 4, 3, 2), ModelTransform.NONE);
        if (hybrid) {
            headData.addChild("cheek_r",
                    ModelPartBuilder.create().uv(44, 0).cuboid(-6, -4, -4, 2, 4, 3), ModelTransform.NONE);
            headData.addChild("cheek_l",
                    ModelPartBuilder.create().uv(44, 8).cuboid(4, -4, -4, 2, 4, 3), ModelTransform.NONE);
        } else {
            headData.addChild("brow",
                    ModelPartBuilder.create().uv(40, 16).cuboid(-4.5f, -6, -5, 9, 2, 2), ModelTransform.NONE);
        }

        rt.addChild("body", ModelPartBuilder.create().uv(0, 16).cuboid(-5, -10, -3, 10, 10, 6),
                ModelTransform.of(0, 16, 0, BODY_TILT, 0, 0));
        rt.addChild("right_arm", ModelPartBuilder.create().uv(0, 32).cuboid(-2, 0, -2, 4, 14, 4),
                ModelTransform.pivot(-7, 8, -1));
        rt.addChild("left_arm", ModelPartBuilder.create().uv(16, 32).cuboid(-2, 0, -2, 4, 14, 4),
                ModelTransform.pivot(7, 8, -1));
        rt.addChild("right_leg", ModelPartBuilder.create().uv(0, 52).cuboid(-2, 0, -2, 4, 8, 4),
                ModelTransform.pivot(-3, 16, 0));
        rt.addChild("left_leg", ModelPartBuilder.create().uv(16, 52).cuboid(-2, 0, -2, 4, 8, 4),
                ModelTransform.pivot(3, 16, 0));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress,
                          float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;

        float swing = limbAngle * 0.6662f;
        rightLeg.pitch = MathHelper.cos(swing) * 1.2f * limbDistance;
        leftLeg.pitch = MathHelper.cos(swing + (float) Math.PI) * 1.2f * limbDistance;
        rightArm.pitch = MathHelper.cos(swing + (float) Math.PI) * 1.0f * limbDistance;
        leftArm.pitch = MathHelper.cos(swing) * 1.0f * limbDistance;

        // napas pelan
        float breath = MathHelper.sin(animationProgress * 0.067f) * 0.03f;
        body.pitch = BODY_TILT + breath;
        rightArm.roll = 0.05f + MathHelper.cos(animationProgress * 0.09f) * 0.03f;
        leftArm.roll = -0.05f - MathHelper.cos(animationProgress * 0.09f) * 0.03f;

        // pukulan: kedua lengan diangkat lalu dihantam
        float atk = entity.handSwingProgress;
        if (atk > 0) {
            float a = MathHelper.sin(atk * (float) Math.PI);
            rightArm.pitch = -2.4f * a;
            leftArm.pitch = -2.4f * a;
            rightArm.roll = 0.15f;
            leftArm.roll = -0.15f;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float r, float g, float b, float a) {
        root.render(matrices, vertices, light, overlay, r, g, b, a);
    }
}
