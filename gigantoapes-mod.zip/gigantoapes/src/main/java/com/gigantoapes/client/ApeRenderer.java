package com.gigantoapes.client;

import com.gigantoapes.entity.ApeEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class ApeRenderer extends MobEntityRenderer<ApeEntity, ApeModel<ApeEntity>> {
    private final Identifier texture;
    private final float scale;

    public ApeRenderer(EntityRendererFactory.Context ctx, net.minecraft.client.render.entity.model.EntityModelLayer layer,
                       Identifier texture, float scale, float shadow) {
        super(ctx, new ApeModel<>(ctx.getPart(layer)), shadow);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public Identifier getTexture(ApeEntity entity) { return texture; }

    @Override
    protected void scale(ApeEntity entity, MatrixStack matrices, float tickDelta) {
        matrices.scale(scale, scale, scale);
    }
}
