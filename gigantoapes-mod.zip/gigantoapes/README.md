# Giganto Apes (Fabric 1.20.1)
Gigantopithecus (120 HP) dan Gorutan = gorila + orangutan (70 HP). Netral, spawn egg + spawn di jungle/bamboo jungle.
Build: push ke GitHub (Actions otomatis `gradle build`) atau lokal `gradle build` (Gradle 8.5, JDK 17). Jar ada di build/libs/.
