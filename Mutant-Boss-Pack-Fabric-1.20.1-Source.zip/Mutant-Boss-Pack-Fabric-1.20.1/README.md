# Mutant Boss Pack — Fabric 1.20.1

Mod Minecraft Java Edition untuk Fabric 1.20.1. Dibangun dengan Java 17, Yarn 1.20.1, Fabric Loader, dan Fabric API.

## Isi mod

| Mob | HP | Lokasi | Mekanik utama |
|---|---:|---|---|
| Mutant Bull | 200 | Plains / Savanna | Charge, ground slam, knockback, dan slowness |
| Mutant Crocodile | 220 | Swamp / Mangrove Swamp | Gerak lebih cepat di air, death-roll effect, blindness dan mining fatigue |
| Mutant Gorilla | 250 | Jungle | Serangan jarak menengah, pound AoE, Rage Mode di 50% HP |
| Boss Minotaur | 500 | Ritual altar | Kombo 3 pukulan, memanggil Labyrinth Guardian saat HP turun |

Semua mob memiliki model 3D dan tekstur khusus. Minotaur tidak muncul secara natural. Serangan jarak menengah Gorilla divisualkan dengan serpihan batu.

## Item dan armor

- **Mutated Horn** — drop Mutant Bull; dipakai untuk memulai ritual Minotaur.
- **Crocodile Scute** — drop Mutant Crocodile; bahan armor Juggernaut.
- **Gorilla Crest** — drop Mutant Gorilla.
- **Minotaur Sigil** — drop Boss Minotaur.

Hadiah yang semula direncanakan sebagai senjata diubah menjadi item trofi non-fungsional; build ini berfokus pada boss, monster, dan armor.
- **Juggernaut Armor** — empat bagian; jika satu set lengkap dipakai saat pemain berada di air, pemain mendapat Resistance singkat yang terus diperbarui.

## Ritual Boss Minotaur

1. Buat alas altar dari **minimal 5 Bone Block** dalam pola 3×3.
2. Pegang Mutated Horn.
3. Klik kanan Bone Block bagian tengah altar.
4. Horn akan digunakan dan Boss Minotaur muncul.

Ritual altar ini dapat dibangun pemain; versi ini belum menambahkan struktur Labyrinth Ruin yang tergenerasi otomatis.

## Cara build melalui GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository (termasuk folder `.github`).
3. Buka tab **Actions**.
4. Pilih **Build Mutant Boss Pack**, lalu tekan **Run workflow**.
5. Setelah workflow selesai, buka hasil run dan unduh artifact `Mutant-Boss-Pack-Fabric-1.20.1`.
6. Ambil file JAR dari artifact tersebut.

Workflow menggunakan Java 17 dan Gradle 8.8. Tidak perlu mengubah nama folder atau path.

## Cara memasang

1. Jalankan Minecraft Java 1.20.1 dengan Fabric Loader.
2. Pasang Fabric API versi 1.20.1.
3. Letakkan `mutant-boss-pack-1.0.0.jar` ke folder `mods`.
4. Jalankan game.

## Perintah uji

```mcfunction
/give @p mutantboss:mutant_bull_spawn_egg
/give @p mutantboss:mutant_crocodile_spawn_egg
/give @p mutantboss:mutant_gorilla_spawn_egg
/give @p mutantboss:mutated_horn
/summon mutantboss:mutant_minotaur
```

## Batas versi

Dibuat khusus untuk **Minecraft Java 1.20.1 + Fabric**. Ini bukan addon Bedrock dan tidak ditujukan untuk semua versi Minecraft.
