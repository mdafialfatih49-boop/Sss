package id.mutantboss;

import id.mutantboss.entity.ModEntities;
import id.mutantboss.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MutantBossMod implements ModInitializer {
    public static final String MOD_ID = "mutantboss";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.register();

        // Natural spawn biomes for the three roaming mutants.
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SAVANNA, BiomeKeys.WINDSWEPT_SAVANNA),
                SpawnGroup.MONSTER, ModEntities.MUTANT_BULL, 18, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.SWAMP, BiomeKeys.MANGROVE_SWAMP),
                SpawnGroup.MONSTER, ModEntities.MUTANT_CROCODILE, 16, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.JUNGLE, BiomeKeys.SPARSE_JUNGLE, BiomeKeys.BAMBOO_JUNGLE),
                SpawnGroup.MONSTER, ModEntities.MUTANT_GORILLA, 10, 1, 1);

        // The complete Crocodile Juggernaut set grants a brief defensive buff while submerged.
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isTouchingWater() && hasJuggernautSet(player)) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 30, 0, true, false, true));
                }
            }
        });
        LOGGER.info("Mutant Boss Pack initialized.");
    }

    private static boolean hasJuggernautSet(PlayerEntity player) {
        return player.getEquippedStack(EquipmentSlot.HEAD).isOf(ModItems.JUGGERNAUT_HELMET)
                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(ModItems.JUGGERNAUT_CHESTPLATE)
                && player.getEquippedStack(EquipmentSlot.LEGS).isOf(ModItems.JUGGERNAUT_LEGGINGS)
                && player.getEquippedStack(EquipmentSlot.FEET).isOf(ModItems.JUGGERNAUT_BOOTS);
    }
}
