package id.mutantboss.client.model;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class MutantBossModel<T extends Entity> extends SinglePartEntityModel<T> {
    public enum Style { BULL, CROCODILE, GORILLA, MINOTAUR }

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart tail;
    private final Style style;

    public MutantBossModel(ModelPart root, Style style) {
        this.root = root;
        this.style = style;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.tail = root.getChild("tail");
    }

    public static TexturedModelData create(Style style) {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        switch (style) {
            case BULL -> {
                root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-11, -14, -8, 22, 25, 16)
                        .uv(0, 44).cuboid(-12, -13, -9, 24, 9, 18), ModelTransform.pivot(0, 14, 0));
                ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(84, 0).cuboid(-7, -8, -7, 14, 13, 13)
                        .uv(84, 28).cuboid(-5, 0, -11, 10, 6, 6), ModelTransform.pivot(0, 4, -7));
                head.addChild("horn_left", ModelPartBuilder.create().uv(0, 74).cuboid(-1, -9, -1, 3, 11, 3), ModelTransform.of(6, -5, 0, 0, 0, -0.48f));
                head.addChild("horn_right", ModelPartBuilder.create().uv(12, 74).cuboid(-2, -9, -1, 3, 11, 3), ModelTransform.of(-6, -5, 0, 0, 0, 0.48f));
                root.addChild("left_arm", ModelPartBuilder.create().uv(48, 74).cuboid(-4, -2, -4, 8, 19, 8), ModelTransform.pivot(-13, 12, 0));
                root.addChild("right_arm", ModelPartBuilder.create().uv(48, 74).cuboid(-4, -2, -4, 8, 19, 8), ModelTransform.pivot(13, 12, 0));
                root.addChild("left_leg", ModelPartBuilder.create().uv(80, 74).cuboid(-4, 0, -4, 8, 14, 8), ModelTransform.pivot(-6, 21, 0));
                root.addChild("right_leg", ModelPartBuilder.create().uv(80, 74).cuboid(-4, 0, -4, 8, 14, 8), ModelTransform.pivot(6, 21, 0));
                root.addChild("tail", ModelPartBuilder.create().uv(108, 74).cuboid(-2, -2, 0, 4, 4, 15), ModelTransform.pivot(0, 15, 8));
            }
            case CROCODILE -> {
                root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-15, -6, -17, 30, 12, 34)
                        .uv(0, 48).cuboid(-14, -9, -14, 28, 4, 28), ModelTransform.pivot(0, 17, 1));
                ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(84, 0).cuboid(-8, -5, -10, 16, 10, 15)
                        .uv(84, 28).cuboid(-6, -2, -20, 12, 5, 11), ModelTransform.pivot(0, 16, -16));
                head.addChild("jaw", ModelPartBuilder.create().uv(84, 44).cuboid(-6, 0, -16, 12, 3, 16), ModelTransform.pivot(0, 3, 0));
                root.addChild("left_arm", ModelPartBuilder.create().uv(0, 82).cuboid(-2, 0, -3, 5, 9, 7), ModelTransform.pivot(-13, 19, -8));
                root.addChild("right_arm", ModelPartBuilder.create().uv(0, 82).cuboid(-3, 0, -3, 5, 9, 7), ModelTransform.pivot(13, 19, -8));
                root.addChild("left_leg", ModelPartBuilder.create().uv(24, 82).cuboid(-2, 0, -3, 5, 9, 7), ModelTransform.pivot(-13, 19, 12));
                root.addChild("right_leg", ModelPartBuilder.create().uv(24, 82).cuboid(-3, 0, -3, 5, 9, 7), ModelTransform.pivot(13, 19, 12));
                root.addChild("tail", ModelPartBuilder.create().uv(48, 82).cuboid(-5, -4, 0, 10, 9, 31)
                        .uv(48, 122).cuboid(-3, -2, 25, 6, 6, 14), ModelTransform.pivot(0, 17, 15));
            }
            case GORILLA -> {
                root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-12, -18, -8, 24, 30, 16)
                        .uv(0, 48).cuboid(-14, -17, -9, 28, 15, 18), ModelTransform.pivot(0, 26, 0));
                ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(88, 0).cuboid(-8, -9, -7, 16, 16, 14)
                        .uv(88, 32).cuboid(-5, 1, -11, 10, 7, 5), ModelTransform.pivot(0, 4, -5));
                head.addChild("fang_left", ModelPartBuilder.create().uv(88, 52).cuboid(-1, 0, -2, 2, 6, 2), ModelTransform.pivot(5, 4, -7));
                head.addChild("fang_right", ModelPartBuilder.create().uv(96, 52).cuboid(-1, 0, -2, 2, 6, 2), ModelTransform.pivot(-5, 4, -7));
                root.addChild("left_arm", ModelPartBuilder.create().uv(48, 74).cuboid(-5, -3, -5, 10, 31, 10), ModelTransform.pivot(-16, 15, 0));
                root.addChild("right_arm", ModelPartBuilder.create().uv(48, 74).cuboid(-5, -3, -5, 10, 31, 10), ModelTransform.pivot(16, 15, 0));
                root.addChild("left_leg", ModelPartBuilder.create().uv(88, 74).cuboid(-5, 0, -5, 10, 16, 10), ModelTransform.pivot(-7, 42, 0));
                root.addChild("right_leg", ModelPartBuilder.create().uv(88, 74).cuboid(-5, 0, -5, 10, 16, 10), ModelTransform.pivot(7, 42, 0));
                root.addChild("tail", ModelPartBuilder.create().cuboid(-1, -1, 0, 2, 2, 2), ModelTransform.pivot(0, 0, 0));
            }
            case MINOTAUR -> {
                root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-13, -25, -9, 26, 38, 18)
                        .uv(0, 58).cuboid(-16, -22, -10, 32, 18, 20), ModelTransform.pivot(0, 30, 0));
                ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(96, 0).cuboid(-9, -11, -8, 18, 18, 16)
                        .uv(96, 38).cuboid(-7, -2, -12, 14, 9, 7), ModelTransform.pivot(0, -1, -7));
                head.addChild("horn_left", ModelPartBuilder.create().uv(64, 92).cuboid(-2, -13, -2, 5, 15, 5), ModelTransform.of(8, -7, 0, 0, 0, -0.35f));
                head.addChild("horn_right", ModelPartBuilder.create().uv(80, 92).cuboid(-3, -13, -2, 5, 15, 5), ModelTransform.of(-8, -7, 0, 0, 0, 0.35f));
                root.addChild("left_arm", ModelPartBuilder.create().uv(48, 92).cuboid(-5, -3, -5, 10, 29, 10), ModelTransform.pivot(-17, 10, 0));
                root.addChild("right_arm", ModelPartBuilder.create().uv(48, 92).cuboid(-5, -3, -5, 10, 29, 10), ModelTransform.pivot(17, 10, 0));
                root.addChild("left_leg", ModelPartBuilder.create().uv(0, 116).cuboid(-5, 0, -5, 10, 20, 10), ModelTransform.pivot(-7, 43, 0));
                root.addChild("right_leg", ModelPartBuilder.create().uv(0, 116).cuboid(-5, 0, -5, 10, 20, 10), ModelTransform.pivot(7, 43, 0));
                root.addChild("tail", ModelPartBuilder.create().uv(40, 122).cuboid(-2, -2, 0, 4, 4, 11), ModelTransform.pivot(0, 33, 8));
            }
        }
        return TexturedModelData.of(data, 128, 128);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        float swing = MathHelper.cos(limbAngle * 0.6662f) * 1.25f * limbDistance;
        leftLeg.pitch = swing;
        rightLeg.pitch = -swing;
        if (style == Style.CROCODILE) {
            tail.yaw = MathHelper.sin(animationProgress * 0.18f) * 0.18f;
            leftArm.pitch = MathHelper.cos(animationProgress * 0.35f) * 0.08f;
            rightArm.pitch = -leftArm.pitch;
        } else {
            leftArm.pitch = MathHelper.cos(limbAngle * 0.6662f + 3.1415927f) * 0.65f * limbDistance;
            rightArm.pitch = MathHelper.cos(limbAngle * 0.6662f) * 0.65f * limbDistance;
            tail.yaw = MathHelper.sin(animationProgress * 0.12f) * 0.08f;
        }
    }
}
