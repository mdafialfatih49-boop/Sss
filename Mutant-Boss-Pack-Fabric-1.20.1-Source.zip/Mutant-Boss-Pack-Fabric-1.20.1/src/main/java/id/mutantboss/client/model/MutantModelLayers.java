package id.mutantboss.client.model;

import id.mutantboss.MutantBossMod;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public final class MutantModelLayers {
    public static final EntityModelLayer BULL = new EntityModelLayer(new Identifier(MutantBossMod.MOD_ID, "mutant_bull"), "main");
    public static final EntityModelLayer CROCODILE = new EntityModelLayer(new Identifier(MutantBossMod.MOD_ID, "mutant_crocodile"), "main");
    public static final EntityModelLayer GORILLA = new EntityModelLayer(new Identifier(MutantBossMod.MOD_ID, "mutant_gorilla"), "main");
    public static final EntityModelLayer MINOTAUR = new EntityModelLayer(new Identifier(MutantBossMod.MOD_ID, "mutant_minotaur"), "main");
    private MutantModelLayers() {}
}
