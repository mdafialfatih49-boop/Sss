package id.mutantboss.client;

import id.mutantboss.MutantBossMod;
import id.mutantboss.client.model.MutantBossModel;
import id.mutantboss.client.model.MutantModelLayers;
import id.mutantboss.entity.ModEntities;
import id.mutantboss.entity.MutantBullEntity;
import id.mutantboss.entity.MutantCrocodileEntity;
import id.mutantboss.entity.MutantGorillaEntity;
import id.mutantboss.entity.MutantMinotaurEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class MutantBossClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(MutantModelLayers.BULL,
                () -> MutantBossModel.create(MutantBossModel.Style.BULL));
        EntityModelLayerRegistry.registerModelLayer(MutantModelLayers.CROCODILE,
                () -> MutantBossModel.create(MutantBossModel.Style.CROCODILE));
        EntityModelLayerRegistry.registerModelLayer(MutantModelLayers.GORILLA,
                () -> MutantBossModel.create(MutantBossModel.Style.GORILLA));
        EntityModelLayerRegistry.registerModelLayer(MutantModelLayers.MINOTAUR,
                () -> MutantBossModel.create(MutantBossModel.Style.MINOTAUR));

        EntityRendererRegistry.register(ModEntities.MUTANT_BULL, context -> new MobEntityRenderer<MutantBullEntity, MutantBossModel<MutantBullEntity>>(
                context, new MutantBossModel<>(context.getPart(MutantModelLayers.BULL), MutantBossModel.Style.BULL), 1.0f) {
            @Override public Identifier getTexture(MutantBullEntity entity) { return texture("mutant_bull.png"); }
        });
        EntityRendererRegistry.register(ModEntities.MUTANT_CROCODILE, context -> new MobEntityRenderer<MutantCrocodileEntity, MutantBossModel<MutantCrocodileEntity>>(
                context, new MutantBossModel<>(context.getPart(MutantModelLayers.CROCODILE), MutantBossModel.Style.CROCODILE), 1.1f) {
            @Override public Identifier getTexture(MutantCrocodileEntity entity) { return texture("mutant_crocodile.png"); }
        });
        EntityRendererRegistry.register(ModEntities.MUTANT_GORILLA, context -> new MobEntityRenderer<MutantGorillaEntity, MutantBossModel<MutantGorillaEntity>>(
                context, new MutantBossModel<>(context.getPart(MutantModelLayers.GORILLA), MutantBossModel.Style.GORILLA), 1.2f) {
            @Override public Identifier getTexture(MutantGorillaEntity entity) { return texture("mutant_gorilla.png"); }
        });
        EntityRendererRegistry.register(ModEntities.MUTANT_MINOTAUR, context -> new MobEntityRenderer<MutantMinotaurEntity, MutantBossModel<MutantMinotaurEntity>>(
                context, new MutantBossModel<>(context.getPart(MutantModelLayers.MINOTAUR), MutantBossModel.Style.MINOTAUR), 1.5f) {
            @Override public Identifier getTexture(MutantMinotaurEntity entity) { return texture("mutant_minotaur.png"); }
        });
    }

    private static Identifier texture(String name) {
        return new Identifier(MutantBossMod.MOD_ID, "textures/entity/" + name);
    }
}
