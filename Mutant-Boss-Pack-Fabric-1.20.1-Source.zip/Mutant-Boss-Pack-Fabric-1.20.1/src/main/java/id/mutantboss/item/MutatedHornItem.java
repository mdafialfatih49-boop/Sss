package id.mutantboss.item;

import id.mutantboss.entity.ModEntities;
import id.mutantboss.entity.MutantMinotaurEntity;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MutatedHornItem extends Item {
    public MutatedHornItem(Settings settings) { super(settings); }

    @Override public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos center = context.getBlockPos();
        PlayerEntity player = context.getPlayer();
        if (!world.getBlockState(center).isOf(Blocks.BONE_BLOCK)) return ActionResult.PASS;
        int boneCount = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (world.getBlockState(center.add(dx, 0, dz)).isOf(Blocks.BONE_BLOCK)) boneCount++;
            }
        }
        if (boneCount < 5 || world.isClient) return ActionResult.PASS;

        MutantMinotaurEntity boss = ModEntities.MUTANT_MINOTAUR.create(world);
        if (boss == null) return ActionResult.PASS;
        boss.refreshPositionAndAngles(center.getX() + 0.5, center.getY() + 1.0, center.getZ() + 0.5,
                player == null ? 0 : player.getYaw(), 0);
        if (world.spawnEntity(boss)) {
            if (player == null || !player.getAbilities().creativeMode) context.getStack().decrement(1);
            return ActionResult.CONSUME;
        }
        return ActionResult.PASS;
    }
}
