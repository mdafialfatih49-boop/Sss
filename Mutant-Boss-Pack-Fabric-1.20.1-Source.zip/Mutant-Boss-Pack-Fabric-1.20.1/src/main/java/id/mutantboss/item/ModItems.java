package id.mutantboss.item;

import id.mutantboss.MutantBossMod;
import id.mutantboss.entity.ModEntities;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(MutantBossMod.MOD_ID, name), item);
    }

    public static final Item MUTATED_HORN = register("mutated_horn", new MutatedHornItem(new FabricItemSettings().maxCount(16)));
    public static final Item CROCODILE_SCUTE = register("crocodile_scute", new Item(new FabricItemSettings().maxCount(64)));
    public static final Item GORILLA_CREST = register("gorilla_crest", new Item(new FabricItemSettings().maxCount(16)));
    public static final Item MINOTAUR_SIGIL = register("minotaur_sigil", new Item(new FabricItemSettings().maxCount(16)));

    public static final JuggernautArmorMaterial JUGGERNAUT_MATERIAL = new JuggernautArmorMaterial();
    public static final Item JUGGERNAUT_HELMET = register("juggernaut_helmet", new ArmorItem(JUGGERNAUT_MATERIAL, ArmorItem.Type.HELMET, new FabricItemSettings()));
    public static final Item JUGGERNAUT_CHESTPLATE = register("juggernaut_chestplate", new ArmorItem(JUGGERNAUT_MATERIAL, ArmorItem.Type.CHESTPLATE, new FabricItemSettings()));
    public static final Item JUGGERNAUT_LEGGINGS = register("juggernaut_leggings", new ArmorItem(JUGGERNAUT_MATERIAL, ArmorItem.Type.LEGGINGS, new FabricItemSettings()));
    public static final Item JUGGERNAUT_BOOTS = register("juggernaut_boots", new ArmorItem(JUGGERNAUT_MATERIAL, ArmorItem.Type.BOOTS, new FabricItemSettings()));

    public static final Item MUTANT_BULL_SPAWN_EGG = register("mutant_bull_spawn_egg",
            new SpawnEggItem(ModEntities.MUTANT_BULL, 0x49352B, 0xC33A24, new FabricItemSettings()));
    public static final Item MUTANT_CROCODILE_SPAWN_EGG = register("mutant_crocodile_spawn_egg",
            new SpawnEggItem(ModEntities.MUTANT_CROCODILE, 0x263D2E, 0x151C17, new FabricItemSettings()));
    public static final Item MUTANT_GORILLA_SPAWN_EGG = register("mutant_gorilla_spawn_egg",
            new SpawnEggItem(ModEntities.MUTANT_GORILLA, 0x292522, 0x9E4A29, new FabricItemSettings()));

    private ModItems() {}

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(MUTATED_HORN);
            entries.add(CROCODILE_SCUTE);
            entries.add(GORILLA_CREST);
            entries.add(MINOTAUR_SIGIL);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(JUGGERNAUT_HELMET);
            entries.add(JUGGERNAUT_CHESTPLATE);
            entries.add(JUGGERNAUT_LEGGINGS);
            entries.add(JUGGERNAUT_BOOTS);
            entries.add(MUTANT_BULL_SPAWN_EGG);
            entries.add(MUTANT_CROCODILE_SPAWN_EGG);
            entries.add(MUTANT_GORILLA_SPAWN_EGG);
        });
    }
}
