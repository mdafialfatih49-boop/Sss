package id.mutantboss.item;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public class JuggernautArmorMaterial implements ArmorMaterial {
    @Override public int getDurability(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 407;
            case CHESTPLATE -> 592;
            case LEGGINGS -> 555;
            case BOOTS -> 481;
            default -> 0;
        };
    }
    @Override public int getProtection(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 3;
            case CHESTPLATE -> 8;
            case LEGGINGS -> 6;
            case BOOTS -> 3;
            default -> 0;
        };
    }
    @Override public int getEnchantability() { return 12; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ITEM_ARMOR_EQUIP_IRON; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.IRON_INGOT); }
    @Override public String getName() { return "mutantboss:juggernaut"; }
    @Override public float getToughness() { return 5.0f; }
    @Override public float getKnockbackResistance() { return 0.15f; }
}
