package id.mutantboss.entity;

import id.mutantboss.item.ModItems;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class MutantBullEntity extends net.minecraft.entity.mob.HostileEntity {
    private int chargeCooldown = 100;
    private int chargeTicks = 0;
    private int slamCooldown = 0;

    public MutantBullEntity(EntityType<? extends MutantBullEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 200.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.29)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 15.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.85)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 38.0);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (chargeCooldown > 0) chargeCooldown--;
        if (slamCooldown > 0) slamCooldown--;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;

        double distance = squaredDistanceTo(target);
        if (chargeTicks > 0) {
            chargeTicks--;
            Vec3d direction = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
            setVelocity(getVelocity().multiply(0.82).add(direction.multiply(0.22, 0, 0.22)));
            velocityModified = true;
            if (distance < 5.5) {
                target.damage(getDamageSources().mobAttack(this), 18.0f);
                target.takeKnockback(2.1, getX() - target.getX(), getZ() - target.getZ());
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
                chargeTicks = 0;
                chargeCooldown = 150;
            }
        } else if (chargeCooldown <= 0 && distance > 20 && distance < 400) {
            chargeTicks = 24;
            getNavigation().stop();
        }

        if (slamCooldown <= 0 && distance < 16 && distance > 3) {
            slamCooldown = 180;
            for (LivingEntity victim : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(4.5), e -> e != this && e.isAlive())) {
                victim.damage(getDamageSources().mobAttack(this), 10.0f);
                victim.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 0));
                victim.takeKnockback(0.9, getX() - victim.getX(), getZ() - victim.getZ());
            }
            getWorld().addParticle(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 0, 0, 0);
            // The shockwave only cracks soft terrain; solid structures remain intact.
            for (BlockPos pos : BlockPos.iterateOutwards(getBlockPos(), 1, 1, 1)) {
                if (getWorld().getBlockState(pos).isOf(Blocks.DIRT) || getWorld().getBlockState(pos).isOf(Blocks.GRAVEL)
                        || getWorld().getBlockState(pos).isOf(Blocks.SAND)) {
                    getWorld().breakBlock(pos, false, this);
                }
            }
        }
    }

    @Override public void onDeath(net.minecraft.entity.damage.DamageSource source) {
        super.onDeath(source);
        if (!getWorld().isClient) dropStack(new ItemStack(ModItems.MUTATED_HORN));
    }
}
