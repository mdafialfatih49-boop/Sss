package id.mutantboss.entity;

import id.mutantboss.MutantBossMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import net.minecraft.registry.tag.FluidTags;

public final class ModEntities {
    public static final EntityType<MutantBullEntity> MUTANT_BULL = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MutantBossMod.MOD_ID, "mutant_bull"),
            FabricEntityTypeBuilder.<MutantBullEntity>createMob()
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MutantBullEntity::new)
                    .dimensions(EntityDimensions.fixed(2.2f, 2.7f))
                    .defaultAttributes(MutantBullEntity::createAttributes)
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                            (type, world, reason, pos, random) -> world.getLightLevel(pos) < 8)
                    .trackRangeBlocks(10).trackedUpdateRate(3).build());

    public static final EntityType<MutantCrocodileEntity> MUTANT_CROCODILE = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MutantBossMod.MOD_ID, "mutant_crocodile"),
            FabricEntityTypeBuilder.<MutantCrocodileEntity>createMob()
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MutantCrocodileEntity::new)
                    .dimensions(EntityDimensions.fixed(3.2f, 1.7f))
                    .defaultAttributes(MutantCrocodileEntity::createAttributes)
                    .spawnRestriction(SpawnRestriction.Location.IN_WATER, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                            (type, world, reason, pos, random) -> world.getFluidState(pos).isIn(FluidTags.WATER))
                    .trackRangeBlocks(12).trackedUpdateRate(3).build());

    public static final EntityType<MutantGorillaEntity> MUTANT_GORILLA = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MutantBossMod.MOD_ID, "mutant_gorilla"),
            FabricEntityTypeBuilder.<MutantGorillaEntity>createMob()
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MutantGorillaEntity::new)
                    .dimensions(EntityDimensions.fixed(2.6f, 4.0f))
                    .defaultAttributes(MutantGorillaEntity::createAttributes)
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                            (type, world, reason, pos, random) -> true)
                    .trackRangeBlocks(12).trackedUpdateRate(3).build());

    public static final EntityType<MutantMinotaurEntity> MUTANT_MINOTAUR = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(MutantBossMod.MOD_ID, "mutant_minotaur"),
            FabricEntityTypeBuilder.<MutantMinotaurEntity>createMob()
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MutantMinotaurEntity::new)
                    .dimensions(EntityDimensions.fixed(3.0f, 4.8f))
                    .defaultAttributes(MutantMinotaurEntity::createAttributes)
                    .trackRangeBlocks(16).trackedUpdateRate(2).build());

    private ModEntities() {}
}
