package id.mutantboss.entity;

import id.mutantboss.item.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HuskEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MutantMinotaurEntity extends net.minecraft.entity.mob.HostileEntity {
    private int comboCooldown = 0;
    private boolean phase75 = false;
    private boolean phase50 = false;
    private boolean phase25 = false;

    public MutantMinotaurEntity(EntityType<? extends MutantMinotaurEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 500.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 24.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.05, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.55));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 24.0f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        float healthRatio = getHealth() / getMaxHealth();
        if (!phase75 && healthRatio <= 0.75f) { phase75 = true; summonMazeGuardians(1); }
        if (!phase50 && healthRatio <= 0.50f) {
            phase50 = true;
            getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.36);
            summonMazeGuardians(2);
        }
        if (!phase25 && healthRatio <= 0.25f) {
            phase25 = true;
            getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(30.0);
            summonMazeGuardians(3);
        }

        if (comboCooldown > 0) comboCooldown--;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (comboCooldown <= 0 && squaredDistanceTo(target) < 25.0) {
            comboCooldown = phase25 ? 55 : 85;
            // Three-beat bare-handed boss combo. The final impact launches the target away.
            for (int hit = 0; hit < 3; hit++) {
                float damage = hit == 2 ? 13.0f : 8.0f;
                target.damage(getDamageSources().mobAttack(this), damage);
                if (hit == 2) {
                    target.takeKnockback(1.8, getX() - target.getX(), getZ() - target.getZ());
                    target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 70, 1));
                }
                getWorld().addParticle(ParticleTypes.CRIT, target.getX(), target.getY() + 1.0, target.getZ(), 0, 0.1, 0);
                if (!target.isAlive()) break;
            }
        }
    }

    private void summonMazeGuardians(int amount) {
        if (getWorld().isClient) return;
        for (int i = 0; i < amount; i++) {
            HuskEntity guardian = EntityType.HUSK.create(getWorld());
            if (guardian == null) continue;
            double angle = (Math.PI * 2.0 * i / Math.max(1, amount)) + random.nextDouble();
            double x = getX() + Math.cos(angle) * 3.5;
            double z = getZ() + Math.sin(angle) * 3.5;
            guardian.refreshPositionAndAngles(x, getY(), z, random.nextFloat() * 360.0f, 0);
            guardian.setCustomName(net.minecraft.text.Text.literal("Labyrinth Guardian"));
            getWorld().spawnEntity(guardian);
        }
        getWorld().addParticle(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.5, getZ(), 0, 0.2, 0);
    }

    @Override public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!getWorld().isClient) dropStack(new ItemStack(ModItems.MINOTAUR_SIGIL));
    }
}
