package id.mutantboss.entity;

import id.mutantboss.item.ModItems;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.world.World;

public class MutantGorillaEntity extends net.minecraft.entity.mob.HostileEntity {
    private int throwCooldown = 0;
    private int poundCooldown = 0;
    private boolean rage = false;

    public MutantGorillaEntity(EntityType<? extends MutantGorillaEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 19.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.9)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 42.0);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.75));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 20.0f));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (throwCooldown > 0) throwCooldown--;
        if (poundCooldown > 0) poundCooldown--;
        if (!rage && getHealth() <= getMaxHealth() * 0.5f) {
            rage = true;
            getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.39);
            getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(25.0);
            getWorld().addParticle(ParticleTypes.ANGRY_VILLAGER, getX(), getY() + 3.2, getZ(), 0, 0.1, 0);
        }
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double distance = squaredDistanceTo(target);

        // Boulder throw: a ranged impact with stone fragments and a strong knockback.
        if (throwCooldown <= 0 && distance > 25 && distance < 400) {
            throwCooldown = rage ? 70 : 105;
            target.damage(getDamageSources().mobAttack(this), rage ? 14.0f : 10.0f);
            target.takeKnockback(1.25, getX() - target.getX(), getZ() - target.getZ());
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 35, 0));
            for (int i = 0; i < 10; i++) {
                getWorld().addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.COBBLESTONE.getDefaultState()),
                        target.getX() + (random.nextDouble() - 0.5), target.getY() + 0.5,
                        target.getZ() + (random.nextDouble() - 0.5), 0, 0.12, 0);
            }
        }

        if (poundCooldown <= 0 && distance < 18 && distance > 4) {
            poundCooldown = rage ? 65 : 95;
            for (LivingEntity victim : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(5.5), e -> e != this && e.isAlive())) {
                victim.damage(getDamageSources().mobAttack(this), rage ? 13.0f : 9.0f);
                victim.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 70, 1));
                victim.takeKnockback(1.0, getX() - victim.getX(), getZ() - victim.getZ());
            }
            getWorld().addParticle(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 0, 0, 0);
        }
    }

    @Override public void onDeath(net.minecraft.entity.damage.DamageSource source) {
        super.onDeath(source);
        if (!getWorld().isClient) dropStack(new ItemStack(ModItems.GORILLA_CREST));
    }
}
