package id.mutantboss.entity;

import id.mutantboss.item.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.world.World;

public class MutantCrocodileEntity extends net.minecraft.entity.mob.HostileEntity {
    private int rollCooldown = 0;
    private int biteTicks = 0;

    public MutantCrocodileEntity(EntityType<? extends MutantCrocodileEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return createHostileAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 220.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 17.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.95)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
        goalSelector.add(6, new WanderAroundFarGoal(this, 0.65));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (rollCooldown > 0) rollCooldown--;
        if (isTouchingWater()) {
            getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.38);
        } else {
            getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.25);
        }
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        double distance = squaredDistanceTo(target);
        if (distance < 6.0 && rollCooldown <= 0) {
            rollCooldown = 160;
            biteTicks = 20;
            target.damage(getDamageSources().mobAttack(this), 15.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 100, 1));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 50, 0));
            target.takeKnockback(1.1, getX() - target.getX(), getZ() - target.getZ());
        }
        if (biteTicks > 0) {
            biteTicks--;
            setYaw(getYaw() + 28.0f);
            if (biteTicks % 4 == 0) getWorld().addParticle(ParticleTypes.BUBBLE, getX(), getY() + 0.4, getZ(), 0, 0.02, 0);
        }
    }

    @Override public void onDeath(net.minecraft.entity.damage.DamageSource source) {
        super.onDeath(source);
        if (!getWorld().isClient) dropStack(new ItemStack(ModItems.CROCODILE_SCUTE, 3 + random.nextInt(3)));
    }
}
