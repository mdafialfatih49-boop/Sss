package com.moonbound.world;

import com.moonbound.MoonBlocks;
import com.moonbound.MoonboundMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

public final class MoonWorld {
    public static final RegistryKey<World> MOON_KEY = RegistryKey.of(RegistryKeys.WORLD, MoonboundMod.id("moon"));
    private static final int SURFACE_Y = 6;

    public static void generateCrater(ServerWorld world, WorldChunk chunk) {
        ChunkPos pos = chunk.getPos();
        int hash = (pos.x * 73428767) ^ (pos.z * 912931);
        if (Math.floorMod(hash, 6) != 0) return;

        int radius = 3 + Math.floorMod(hash >>> 4, 4);
        int centerX = pos.getStartX() + 8;
        int centerZ = pos.getStartZ() + 8;
        BlockState floor = MoonBlocks.CRATER_FLOOR.getDefaultState();
        BlockState rim = MoonBlocks.CRATER_RIM.getDefaultState();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double distance = Math.sqrt(dx * dx + dz * dz);
                if (distance > radius) continue;
                int depth = Math.max(1, MathHelper.ceil((1.0 - distance / (radius + 0.5)) * 3.0));
                int x = centerX + dx;
                int z = centerZ + dz;
                if (distance >= radius - 0.7) {
                    world.setBlockState(new BlockPos(x, SURFACE_Y, z), rim, 3);
                    continue;
                }
                int bottom = SURFACE_Y - depth;
                for (int y = bottom + 1; y <= SURFACE_Y; y++) {
                    world.setBlockState(new BlockPos(x, y, z), Blocks.AIR.getDefaultState(), 3);
                }
                world.setBlockState(new BlockPos(x, bottom, z), floor, 3);
            }
        }
    }

    public static void generateLunarOres(ServerWorld world, WorldChunk chunk) {
        ChunkPos pos = chunk.getPos();
        int hash = (pos.x * 19349663) ^ (pos.z * 83492791);
        // A small number of ore clusters are embedded in the Moon Stone below the dust.
        for (int i = 0; i < 2; i++) {
            int x = pos.getStartX() + 1 + Math.floorMod(hash >>> (i * 5), 14);
            int z = pos.getStartZ() + 1 + Math.floorMod((hash * (i + 3)) >>> 7, 14);
            int y = 1 + Math.floorMod(hash >>> (i * 3 + 2), 5);
            BlockPos orePos = new BlockPos(x, y, z);
            if (world.getBlockState(orePos).isOf(MoonBlocks.MOON_STONE)) {
                world.setBlockState(orePos, MoonBlocks.LUNAR_CRYSTAL_ORE.getDefaultState(), 3);
            }
        }
    }

    public static void ensureEarthCube(ServerWorld world, WorldChunk chunk) {
        // One 11-block cube floats above the Moon's spawn area, in chunk (0, -4).
        if (chunk.getPos().x != 0 || chunk.getPos().z != -4) return;
        int minX = 3;
        int minY = 118;
        int minZ = -61;
        int size = 11;

        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                for (int z = 0; z < size; z++) {
                    BlockState state = MoonBlocks.EARTH_OCEAN.getDefaultState();
                    // Green land shapes across the front face, with a few clouds on top.
                    boolean land = (x >= 2 && x <= 4 && y >= 5 && y <= 8 && z == size - 1)
                            || (x >= 6 && x <= 9 && y >= 2 && y <= 5 && z == size - 1)
                            || (x >= 4 && x <= 7 && y >= 7 && y <= 9 && z == size - 1)
                            || (z == 0 && x >= 2 && x <= 5 && y >= 3 && y <= 6)
                            || (x == 0 && z >= 3 && z <= 7 && y >= 4 && y <= 7);
                    boolean cloud = (y == size - 1 && ((x + z) % 5 == 0 || (x + 2 * z) % 7 == 0));
                    if (land) state = MoonBlocks.EARTH_LAND.getDefaultState();
                    if (cloud) state = MoonBlocks.EARTH_CLOUD.getDefaultState();
                    world.setBlockState(new BlockPos(minX + x, minY + y, minZ + z), state, 3);
                }
            }
        }
    }

    private MoonWorld() {}
}
