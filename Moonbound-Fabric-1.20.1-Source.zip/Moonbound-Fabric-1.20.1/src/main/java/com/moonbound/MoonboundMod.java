package com.moonbound;

import com.moonbound.entity.MoonEntities;
import com.moonbound.item.MoonItems;
import com.moonbound.world.MoonWorld;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MoonboundMod implements ModInitializer {
    public static final String MOD_ID = "moonbound";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        MoonBlocks.register();
        MoonEntities.register();
        MoonItems.register();

        // Low gravity: reduce the normal downward acceleration for players on the Moon.
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!world.getRegistryKey().equals(MoonWorld.MOON_KEY)) return;
            for (PlayerEntity player : world.getPlayers()) {
                if (!player.isOnGround() && !player.getAbilities().flying && !player.isFallFlying()) {
                    Vec3d velocity = player.getVelocity();
                    player.setVelocity(velocity.x, Math.min(velocity.y + 0.0785, 0.42), velocity.z);
                    player.velocityModified = true;
                }
            }
        });

        // Add deterministic crater bowls as lunar chunks are loaded.
        ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            if (!world.getRegistryKey().equals(MoonWorld.MOON_KEY)) return;
            MoonWorld.generateCrater(world, chunk);
            MoonWorld.generateLunarOres(world, chunk);
            MoonWorld.ensureEarthCube(world, chunk);
        });

        LOGGER.info("Moonbound loaded: rocket, Moon dimension, low gravity and lunar life are ready.");
    }
}
