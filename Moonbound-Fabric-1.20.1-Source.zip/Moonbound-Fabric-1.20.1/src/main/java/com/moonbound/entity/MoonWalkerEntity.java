package com.moonbound.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;

public class MoonWalkerEntity extends ZombieEntity {
    public MoonWalkerEntity(EntityType<? extends ZombieEntity> entityType, World world) {
        super(entityType, world);
    }
}
