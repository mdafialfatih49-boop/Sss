package com.moonbound.item;

import com.moonbound.MoonBlocks;
import com.moonbound.MoonboundMod;
import com.moonbound.entity.MoonEntities;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class MoonItems {
    public static final Item ROCKET = Registry.register(Registries.ITEM, MoonboundMod.id("rocket"), new RocketItem(new Item.Settings().maxCount(1)));
    public static final Item LUNAR_CRYSTAL = Registry.register(Registries.ITEM, MoonboundMod.id("lunar_crystal"), new Item(new Item.Settings()));
    public static final Item MOON_WALKER_SPAWN_EGG = Registry.register(Registries.ITEM, MoonboundMod.id("moon_walker_spawn_egg"), new SpawnEggItem(MoonEntities.MOON_WALKER, 0x5A5E68, 0xC6C8D2, new Item.Settings()));
    public static final Item MOON_SLIME_SPAWN_EGG = Registry.register(Registries.ITEM, MoonboundMod.id("moon_slime_spawn_egg"), new SpawnEggItem(MoonEntities.MOON_SLIME, 0x37334E, 0xCBA8FF, new Item.Settings()));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, MoonboundMod.id("items"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(ROCKET))
                    .displayName(Text.translatable("itemGroup.moonbound.main"))
                    .entries((context, entries) -> {
                        entries.add(ROCKET);
                        entries.add(LUNAR_CRYSTAL);
                        entries.add(MoonBlocks.MOON_STONE);
                        entries.add(MoonBlocks.MOON_DUST);
                        entries.add(MoonBlocks.CRATER_FLOOR);
                        entries.add(MoonBlocks.CRATER_RIM);
                        entries.add(MoonBlocks.LUNAR_CRYSTAL_ORE);
                        entries.add(MoonBlocks.LUNAR_CRYSTAL_BLOCK);
                        entries.add(MOON_WALKER_SPAWN_EGG);
                        entries.add(MOON_SLIME_SPAWN_EGG);
                        entries.add(MoonBlocks.EARTH_OCEAN);
                        entries.add(MoonBlocks.EARTH_LAND);
                        entries.add(MoonBlocks.EARTH_CLOUD);
                    }).build());

    public static void register() {
        MoonboundMod.LOGGER.info("Registering Moonbound items");
    }

    private MoonItems() {}
}
