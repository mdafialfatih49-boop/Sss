package com.moonbound.item;

import com.moonbound.world.MoonWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class RocketItem extends Item {
    public RocketItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity player) {
            ServerWorld destination;
            boolean goingToMoon = world.getRegistryKey().equals(World.OVERWORLD);
            if (goingToMoon) {
                destination = player.getServer().getWorld(MoonWorld.MOON_KEY);
            } else if (world.getRegistryKey().equals(MoonWorld.MOON_KEY)) {
                destination = player.getServer().getWorld(World.OVERWORLD);
            } else {
                destination = null;
            }

            if (destination == null) {
                player.sendMessage(Text.literal("The rocket can only travel between the Overworld and the Moon."), true);
                return TypedActionResult.fail(stack);
            }

            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.PLAYERS, 1.0f, 0.75f);
            BlockPos safeSpawn = destination.getSpawnPos().up();
            double x = goingToMoon ? 0.5 : safeSpawn.getX() + 0.5;
            double z = goingToMoon ? 0.5 : safeSpawn.getZ() + 0.5;
            double y = goingToMoon ? 8.0 : safeSpawn.getY();
            boolean moved = player.teleport(destination, x, y, z, java.util.Set.of(), player.getYaw(), player.getPitch());
            if (moved) {
                player.sendMessage(Text.literal(goingToMoon ? "Rocket launched! Welcome to the Moon." : "Returning to the Overworld."), false);
            }
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
