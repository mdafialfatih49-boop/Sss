package com.moonbound;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class MoonBlocks {
    public static final Block MOON_STONE = register("moon_stone", new Block(AbstractBlock.Settings.copy(Blocks.STONE).strength(2.2f, 6.0f)));
    public static final Block MOON_DUST = register("moon_dust", new Block(AbstractBlock.Settings.copy(Blocks.SAND).strength(0.5f).sounds(net.minecraft.sound.BlockSoundGroup.SAND)));
    public static final Block CRATER_FLOOR = register("crater_floor", new Block(AbstractBlock.Settings.copy(Blocks.TUFF).strength(1.8f, 5.0f)));
    public static final Block CRATER_RIM = register("crater_rim", new Block(AbstractBlock.Settings.copy(Blocks.ANDESITE).strength(2.4f, 6.0f)));
    public static final Block LUNAR_CRYSTAL_ORE = register("lunar_crystal_ore", new Block(AbstractBlock.Settings.copy(Blocks.DIAMOND_ORE).strength(3.0f, 6.0f)));
    public static final Block LUNAR_CRYSTAL_BLOCK = register("lunar_crystal_block", new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(2.0f, 6.0f).luminance(state -> 7)));

    // Decorative blocks used to build the cube-shaped Earth landmark in the sky.
    public static final Block EARTH_OCEAN = register("earth_ocean", new Block(AbstractBlock.Settings.copy(Blocks.BLUE_CONCRETE).strength(1.5f)));
    public static final Block EARTH_LAND = register("earth_land", new Block(AbstractBlock.Settings.copy(Blocks.GREEN_CONCRETE).strength(1.5f)));
    public static final Block EARTH_CLOUD = register("earth_cloud", new Block(AbstractBlock.Settings.copy(Blocks.WHITE_CONCRETE).strength(1.5f)));

    private static Block register(String name, Block block) {
        Registry.register(Registries.BLOCK, MoonboundMod.id(name), block);
        Registry.register(Registries.ITEM, MoonboundMod.id(name), new BlockItem(block, new Item.Settings()));
        return block;
    }

    public static void register() {
        MoonboundMod.LOGGER.info("Registering Moonbound blocks");
    }

    private MoonBlocks() {}
}
