package com.moonbound;

import com.moonbound.entity.MoonEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.SlimeEntityRenderer;
import net.minecraft.client.render.entity.ZombieEntityRenderer;

@SuppressWarnings({"rawtypes", "unchecked"})
public class MoonboundClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(MoonEntities.MOON_WALKER, context -> (net.minecraft.client.render.entity.EntityRenderer) new MoonWalkerRenderer(context));
        EntityRendererRegistry.register(MoonEntities.MOON_SLIME, context -> (net.minecraft.client.render.entity.EntityRenderer) new MoonSlimeRenderer(context));
    }

    private static class MoonWalkerRenderer extends ZombieEntityRenderer {
        MoonWalkerRenderer(net.minecraft.client.render.entity.EntityRendererFactory.Context context) {
            super(context);
        }

        @Override
        public net.minecraft.util.Identifier getTexture(net.minecraft.entity.mob.ZombieEntity entity) {
            return MoonboundMod.id("textures/entity/moon_walker.png");
        }
    }

    private static class MoonSlimeRenderer extends SlimeEntityRenderer {
        MoonSlimeRenderer(net.minecraft.client.render.entity.EntityRendererFactory.Context context) {
            super(context);
        }

        @Override
        public net.minecraft.util.Identifier getTexture(net.minecraft.entity.mob.SlimeEntity entity) {
            return MoonboundMod.id("textures/entity/moon_slime.png");
        }
    }
}
