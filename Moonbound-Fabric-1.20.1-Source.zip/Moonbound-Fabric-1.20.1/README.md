# Moonbound: Lunar Exploration

Mod Minecraft Java Edition **Fabric 1.20.1**. This source project adds a Moon dimension and a small lunar-exploration content pack.

## Fitur

- **Dimensi Bulan** (`moonbound:moon`) dengan permukaan datar berlapis Moon Dust dan Moon Stone.
- **Gravitasi sangat rendah** saat pemain berada di Bulan, sehingga lompatan dan jatuh terasa melayang.
- **Langit malam permanen** dengan bintang-bintang. Ada landmark Bumi berbentuk kubus yang mengambang di atas area awal Bulan.
- **Kawah Bulan** dengan bagian tengah yang lebih rendah, dinding/rim kawah, serta variasi permukaan.
- **Blok baru:** Moon Stone, Moon Dust, Crater Floor, Crater Rim, Lunar Crystal Ore, Lunar Crystal Block, dan blok dekorasi Bumi.
- **Mob baru:** Moon Walker dan Moon Slime. Keduanya memiliki texture khusus serta spawn egg.
- **Roket yang dapat dipakai ulang:** klik kanan di Overworld untuk pergi ke Bulan, lalu klik kanan lagi di Bulan untuk kembali.
- Resep crafting untuk Space Rocket dan Lunar Crystal Block.

## Cara memakai roket

1. Buat **Space Rocket** menggunakan resep di crafting table: `IRI / SFS / IRI`.
2. `I` = Iron Ingot, `R` = Redstone, `S` = Smooth Stone, dan `F` = Firework Rocket.
3. Pegang roket lalu klik kanan di Overworld untuk pergi ke Bulan.
4. Pegang roket dan klik kanan lagi di Bulan untuk kembali ke titik spawn Overworld.

Roket bersifat reusable sehingga satu roket cukup untuk perjalanan pulang-pergi.

## Cara build melalui GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository, termasuk folder `.github`.
3. Buka tab **Actions**.
4. Pilih workflow **Build Moonbound Mod**, lalu pilih **Run workflow**.
5. Setelah workflow selesai, buka hasil run dan unduh artifact bernama `Moonbound-Fabric-1.20.1`.
6. Pasang JAR hasil build bersama Fabric Loader 1.20.1 dan Fabric API 0.92.2+1.20.1.

## Build lokal

Perlu Java 17 dan Gradle 8.8. Dari root proyek jalankan:

```bash
gradle build
```

JAR utama akan dibuat di:

```text
build/libs/Moonbound-Fabric-1.20.1-1.0.0.jar
```

## Catatan teknis

- Proyek menggunakan Java 17, Yarn `1.20.1+build.10`, Fabric Loader `0.15.11`, Fabric API `0.92.2+1.20.1`, dan Fabric Loom `1.6.12`.
- Definisi dimensi dan biome berada di resource `data/moonbound/`.
- Kawah, bijih Lunar Crystal, dan landmark Bumi dibuat secara deterministik ketika chunk Bulan dimuat.
- Build JAR belum dapat dijalankan di lingkungan pembuat file ini karena Gradle tidak terpasang dan akses jaringan untuk mengambil distribusi Gradle tidak tersedia. Workflow GitHub Actions disertakan untuk menjalankan build dengan Gradle 8.8.
