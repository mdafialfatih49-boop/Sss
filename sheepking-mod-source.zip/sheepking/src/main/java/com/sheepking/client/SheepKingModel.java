package com.sheepking.client;

import com.sheepking.entity.SheepKingEntity;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.QuadrupedEntityModel;

/** Model empat kaki, UV mengikuti layout skin pemain 64x64 supaya skin asli bisa langsung dipakai. */
public class SheepKingModel extends QuadrupedEntityModel<SheepKingEntity> {
	public SheepKingModel(ModelPart root) {
		super(root, false, 8.0f, 4.0f, 2.0f, 2.0f, 24);
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData root = data.getRoot();
		root.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-4.0f, -4.0f, -8.0f, 8.0f, 8.0f, 8.0f),
				ModelTransform.pivot(0.0f, 6.0f, -4.0f));
		root.addChild("body", ModelPartBuilder.create().uv(16, 16)
						.cuboid(-4.0f, -8.0f, -6.0f, 8.0f, 12.0f, 4.0f, new Dilation(1.0f)),
				ModelTransform.of(0.0f, 5.0f, 2.0f, (float) (Math.PI / 2), 0.0f, 0.0f));
		ModelPartBuilder hind = ModelPartBuilder.create().uv(0, 16).cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f);
		ModelPartBuilder front = ModelPartBuilder.create().uv(40, 16).cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f);
		root.addChild("right_hind_leg", hind, ModelTransform.pivot(-3.5f, 12.0f, 5.0f));
		root.addChild("left_hind_leg", hind, ModelTransform.pivot(3.5f, 12.0f, 5.0f));
		root.addChild("right_front_leg", front, ModelTransform.pivot(-3.5f, 12.0f, -5.0f));
		root.addChild("left_front_leg", front, ModelTransform.pivot(3.5f, 12.0f, -5.0f));
		return TexturedModelData.of(data, 64, 64);
	}
}
