package com.sheepking.client;

import com.sheepking.entity.SheepKingEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class SheepKingRenderer extends MobEntityRenderer<SheepKingEntity, SheepKingModel> {
	private static final Identifier TEXTURE = new Identifier("sheepking", "textures/entity/sheep_king.png");

	public SheepKingRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new SheepKingModel(ctx.getPart(SheepKingClient.SHEEP_KING_LAYER)), 0.7f);
	}

	@Override
	public Identifier getTexture(SheepKingEntity entity) {
		return TEXTURE;
	}

	@Override
	protected void scale(SheepKingEntity entity, MatrixStack matrices, float amount) {
		matrices.scale(1.2f, 1.2f, 1.2f);
	}
}
