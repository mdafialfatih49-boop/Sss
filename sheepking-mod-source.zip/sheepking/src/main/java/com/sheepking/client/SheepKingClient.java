package com.sheepking.client;

import com.sheepking.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class SheepKingClient implements ClientModInitializer {
	public static final EntityModelLayer SHEEP_KING_LAYER =
			new EntityModelLayer(new Identifier("sheepking", "sheep_king"), "main");

	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(SHEEP_KING_LAYER, SheepKingModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.SHEEP_KING, SheepKingRenderer::new);
		EntityRendererRegistry.register(ModEntities.SHEEP_BODYGUARD, BodyguardRenderer::new);
	}
}
