package com.sheepking.client;

import com.sheepking.entity.BodyguardEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class BodyguardRenderer extends MobEntityRenderer<BodyguardEntity, BodyguardModel> {
	private static final Identifier TEXTURE = new Identifier("sheepking", "textures/entity/sheep_bodyguard.png");

	public BodyguardRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new BodyguardModel(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.9f);
	}

	@Override
	public Identifier getTexture(BodyguardEntity entity) {
		return TEXTURE;
	}

	@Override
	protected void scale(BodyguardEntity entity, MatrixStack matrices, float amount) {
		matrices.scale(1.45f, 1.45f, 1.45f);
	}
}
