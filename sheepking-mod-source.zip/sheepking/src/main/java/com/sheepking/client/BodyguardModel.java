package com.sheepking.client;

import com.sheepking.entity.BodyguardEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;

public class BodyguardModel extends BipedEntityModel<BodyguardEntity> {
	public BodyguardModel(ModelPart root) {
		super(root);
	}

	@Override
	public void setAngles(BodyguardEntity entity, float limbAngle, float limbDistance,
						  float animationProgress, float headYaw, float headPitch) {
		super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
		if (entity.isSlamming()) {
			float up = (float) (-Math.PI * 0.9);
			this.rightArm.pitch = up;
			this.leftArm.pitch = up;
			this.rightArm.yaw = 0.0f;
			this.leftArm.yaw = 0.0f;
			this.rightArm.roll = 0.15f;
			this.leftArm.roll = -0.15f;
		}
	}
}
