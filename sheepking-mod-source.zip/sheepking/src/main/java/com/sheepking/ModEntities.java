package com.sheepking;

import com.sheepking.entity.BodyguardEntity;
import com.sheepking.entity.SheepKingEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
	public static final EntityType<SheepKingEntity> SHEEP_KING = Registry.register(
			Registries.ENTITY_TYPE, new Identifier(SheepKingMod.MOD_ID, "sheep_king"),
			FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, SheepKingEntity::new)
					.dimensions(EntityDimensions.fixed(0.9f, 1.7f)).trackRangeBlocks(80).build());

	public static final EntityType<BodyguardEntity> SHEEP_BODYGUARD = Registry.register(
			Registries.ENTITY_TYPE, new Identifier(SheepKingMod.MOD_ID, "sheep_bodyguard"),
			FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, BodyguardEntity::new)
					.dimensions(EntityDimensions.fixed(1.0f, 2.7f)).trackRangeBlocks(80).build());

	public static void register() {
		FabricDefaultAttributeRegistry.register(SHEEP_KING, SheepKingEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(SHEEP_BODYGUARD, BodyguardEntity.createAttributes());

		Item kingEgg = Registry.register(Registries.ITEM, new Identifier(SheepKingMod.MOD_ID, "sheep_king_spawn_egg"),
				new SpawnEggItem(SHEEP_KING, 0xFFFFFF, 0xFFD700, new Item.Settings()));
		Item guardEgg = Registry.register(Registries.ITEM, new Identifier(SheepKingMod.MOD_ID, "sheep_bodyguard_spawn_egg"),
				new SpawnEggItem(SHEEP_BODYGUARD, 0x111111, 0x2A7FD4, new Item.Settings()));

		ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
			entries.add(kingEgg);
			entries.add(guardEgg);
		});
	}
}
