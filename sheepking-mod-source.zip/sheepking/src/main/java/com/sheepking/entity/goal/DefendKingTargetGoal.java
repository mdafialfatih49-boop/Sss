package com.sheepking.entity.goal;

import com.sheepking.entity.BodyguardEntity;
import com.sheepking.entity.SheepKingEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.TargetPredicate;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.TrackTargetGoal;
import net.minecraft.entity.mob.HostileEntity;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

public class DefendKingTargetGoal extends TrackTargetGoal {
	private final BodyguardEntity guard;
	private LivingEntity threat;

	public DefendKingTargetGoal(BodyguardEntity guard) {
		super(guard, false);
		this.guard = guard;
		this.setControls(EnumSet.of(Goal.Control.TARGET));
	}

	@Override
	public boolean canStart() {
		SheepKingEntity king = guard.getKing();
		if (king == null) {
			return false;
		}
		LivingEntity attacker = king.getAttacker();
		if (attacker != null && attacker.isAlive() && !isAlly(attacker)
				&& king.age - king.getLastAttackedTime() < 200
				&& canTrack(attacker, TargetPredicate.DEFAULT)) {
			threat = attacker;
			return true;
		}
		List<HostileEntity> list = guard.getWorld().getEntitiesByClass(HostileEntity.class,
				king.getBoundingBox().expand(16.0), h -> h.isAlive() && h.getTarget() == king);
		list.sort(Comparator.comparingDouble(h -> h.squaredDistanceTo(king)));
		if (!list.isEmpty()) {
			threat = list.get(0);
			return true;
		}
		return false;
	}

	private boolean isAlly(LivingEntity e) {
		return e instanceof SheepKingEntity || e instanceof BodyguardEntity;
	}

	@Override
	public void start() {
		guard.setTarget(threat);
		super.start();
	}
}
