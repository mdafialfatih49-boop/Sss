package com.sheepking.entity;

import com.sheepking.entity.goal.DefendKingTargetGoal;
import com.sheepking.entity.goal.FollowKingGoal;
import com.sheepking.entity.goal.SlamAttackGoal;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class BodyguardEntity extends PathAwareEntity {
	private static final TrackedData<Boolean> SLAMMING =
			DataTracker.registerData(BodyguardEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

	private UUID kingUuid;
	private int orphanTicks = 0;

	public BodyguardEntity(EntityType<? extends BodyguardEntity> type, World world) {
		super(type, world);
		this.setStepHeight(1.0f);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return MobEntity.createMobAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
				.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.9)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
				.add(EntityAttributes.GENERIC_ARMOR, 6.0)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
	}

	@Override
	protected void initDataTracker() {
		super.initDataTracker();
		this.dataTracker.startTracking(SLAMMING, false);
	}

	public boolean isSlamming() {
		return this.dataTracker.get(SLAMMING);
	}

	public void setSlamming(boolean value) {
		this.dataTracker.set(SLAMMING, value);
	}

	@Nullable
	public UUID getKingUuid() {
		return kingUuid;
	}

	public void setKingUuid(UUID uuid) {
		this.kingUuid = uuid;
	}

	@Nullable
	public SheepKingEntity getKing() {
		if (kingUuid != null && this.getWorld() instanceof ServerWorld sw) {
			Entity e = sw.getEntity(kingUuid);
			if (e instanceof SheepKingEntity k && k.isAlive()) {
				return k;
			}
		}
		return null;
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(1, new SlamAttackGoal(this));
		this.goalSelector.add(2, new FollowKingGoal(this, 1.1));
		this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
		this.goalSelector.add(4, new LookAroundGoal(this));
		this.targetSelector.add(1, new DefendKingTargetGoal(this));
		this.targetSelector.add(2, new RevengeGoal(this, BodyguardEntity.class, SheepKingEntity.class));
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.getWorld().isClient && kingUuid != null && this.age % 20 == 0) {
			if (getKing() == null) {
				orphanTicks += 20;
				if (orphanTicks >= 400 && this.getWorld() instanceof ServerWorld sw) {
					sw.spawnParticles(ParticleTypes.POOF, this.getX(), this.getY() + 1.3, this.getZ(), 30, 0.5, 1.0, 0.5, 0.05);
					this.discard();
				}
			} else {
				orphanTicks = 0;
			}
		}
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		if (kingUuid != null) {
			nbt.putUuid("King", kingUuid);
		}
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		if (nbt.containsUuid("King")) {
			kingUuid = nbt.getUuid("King");
		}
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_IRON_GOLEM_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_IRON_GOLEM_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.ENTITY_IRON_GOLEM_STEP, 0.8f, 0.8f);
	}
}
