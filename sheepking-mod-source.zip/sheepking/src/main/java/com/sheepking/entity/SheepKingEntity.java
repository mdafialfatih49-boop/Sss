package com.sheepking.entity;

import com.sheepking.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.EscapeDangerGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class SheepKingEntity extends PathAwareEntity {
	private long nextSummonTime = 0;

	public SheepKingEntity(EntityType<? extends SheepKingEntity> type, World world) {
		super(type, world);
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return MobEntity.createMobAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
				.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.5);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(1, new EscapeDangerGoal(this, 1.5));
		this.goalSelector.add(2, new WanderAroundFarGoal(this, 0.8));
		this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
		this.goalSelector.add(4, new LookAroundGoal(this));
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		boolean hurt = super.damage(source, amount);
		if (hurt && !this.getWorld().isClient) {
			callGuards();
		}
		return hurt;
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.getWorld().isClient && this.isAlive() && this.age % 20 == 0) {
			boolean threatened = !this.getWorld()
					.getEntitiesByClass(HostileEntity.class, this.getBoundingBox().expand(10.0),
							h -> h.isAlive() && h.getTarget() == this)
					.isEmpty();
			if (threatened) {
				callGuards();
			}
		}
	}

	private void callGuards() {
		if (!(this.getWorld() instanceof ServerWorld sw)) {
			return;
		}
		if (sw.getTime() < nextSummonTime) {
			return;
		}
		int alive = sw.getEntitiesByClass(BodyguardEntity.class, this.getBoundingBox().expand(64.0),
				g -> g.isAlive() && this.getUuid().equals(g.getKingUuid())).size();
		if (alive >= 2) {
			return;
		}
		nextSummonTime = sw.getTime() + 100;
		for (int i = alive; i < 2; i++) {
			BodyguardEntity g = ModEntities.SHEEP_BODYGUARD.create(sw);
			if (g == null) {
				continue;
			}
			double ang = Math.toRadians(this.getYaw()) + (i == 0 ? Math.PI / 2 : -Math.PI / 2);
			double x = this.getX() - Math.sin(ang) * 2.2;
			double z = this.getZ() + Math.cos(ang) * 2.2;
			g.refreshPositionAndAngles(x, this.getY(), z, this.getYaw(), 0.0f);
			if (!sw.isSpaceEmpty(g)) {
				g.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), this.getYaw(), 0.0f);
			}
			g.setKingUuid(this.getUuid());
			sw.spawnEntity(g);
			sw.spawnParticles(ParticleTypes.POOF, x, this.getY() + 1.0, z, 25, 0.4, 0.9, 0.4, 0.05);
		}
		sw.playSound(null, this.getBlockPos(), SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, SoundCategory.HOSTILE, 1.5f, 0.8f);
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		return false;
	}

	@Nullable
	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.ENTITY_SHEEP_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_SHEEP_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_SHEEP_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.ENTITY_SHEEP_STEP, 0.15f, 1.0f);
	}
}
