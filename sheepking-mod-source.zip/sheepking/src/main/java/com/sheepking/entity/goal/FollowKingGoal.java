package com.sheepking.entity.goal;

import com.sheepking.entity.BodyguardEntity;
import com.sheepking.entity.SheepKingEntity;
import net.minecraft.entity.ai.goal.Goal;

import java.util.EnumSet;

public class FollowKingGoal extends Goal {
	private final BodyguardEntity guard;
	private final double speed;
	private SheepKingEntity king;

	public FollowKingGoal(BodyguardEntity guard, double speed) {
		this.guard = guard;
		this.speed = speed;
		this.setControls(EnumSet.of(Goal.Control.MOVE));
	}

	@Override
	public boolean canStart() {
		king = guard.getKing();
		return king != null && guard.squaredDistanceTo(king) > 36.0;
	}

	@Override
	public boolean shouldContinue() {
		return king != null && king.isAlive() && guard.squaredDistanceTo(king) > 12.0
				&& !guard.getNavigation().isIdle();
	}

	@Override
	public void tick() {
		if (king == null) {
			return;
		}
		if (guard.squaredDistanceTo(king) > 1600.0) {
			guard.refreshPositionAndAngles(king.getX(), king.getY(), king.getZ(), guard.getYaw(), 0.0f);
			guard.getNavigation().stop();
			return;
		}
		if (guard.age % 10 == 0) {
			guard.getNavigation().startMovingTo(king, speed);
		}
	}

	@Override
	public void start() {
		guard.getNavigation().startMovingTo(king, speed);
	}

	@Override
	public void stop() {
		guard.getNavigation().stop();
		king = null;
	}
}
