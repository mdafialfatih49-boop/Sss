package com.sheepking.entity.goal;

import com.sheepking.entity.BodyguardEntity;
import com.sheepking.entity.SheepKingEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;

import java.util.EnumSet;

/**
 * Bodyguard mendekati penyerang, mengangkatnya di atas kepala, lalu membantingnya
 * ke tanah: kawah besar + partikel ledakan besar, target mati.
 */
public class SlamAttackGoal extends Goal {
	private static final int LIFT_TICKS = 22;
	private static final int RECOVER_TICKS = 15;
	private static final int CRATER_RADIUS = 4;

	private final BodyguardEntity guard;
	private LivingEntity victim;
	private int phase; // 0 = mendekat, 1 = angkat, 2 = pemulihan, 3 = selesai
	private int timer;
	private long nextSlam = 0;

	public SlamAttackGoal(BodyguardEntity guard) {
		this.guard = guard;
		this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
	}

	@Override
	public boolean canStart() {
		LivingEntity t = guard.getTarget();
		if (t == null || !t.isAlive() || t instanceof SheepKingEntity || t instanceof BodyguardEntity) {
			return false;
		}
		return guard.getWorld().getTime() >= nextSlam;
	}

	@Override
	public boolean shouldContinue() {
		return phase < 3 && victim != null && (phase >= 2 || victim.isAlive());
	}

	@Override
	public void start() {
		victim = guard.getTarget();
		phase = 0;
		timer = 0;
	}

	@Override
	public void stop() {
		guard.setSlamming(false);
		guard.getNavigation().stop();
		nextSlam = guard.getWorld().getTime() + 60;
		victim = null;
	}

	@Override
	public boolean shouldRunEveryTick() {
		return true;
	}

	@Override
	public void tick() {
		if (victim == null) {
			return;
		}
		timer++;
		switch (phase) {
			case 0 -> {
				guard.getLookControl().lookAt(victim, 30.0f, 30.0f);
				guard.getNavigation().startMovingTo(victim, 1.2);
				if (guard.squaredDistanceTo(victim) < 9.0) {
					phase = 1;
					timer = 0;
					guard.getNavigation().stop();
					guard.setSlamming(true);
					guard.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 1.5f, 0.7f);
				} else if (timer > 200) {
					phase = 3;
				}
			}
			case 1 -> {
				guard.getNavigation().stop();
				hold();
				if (timer >= LIFT_TICKS) {
					slam();
					guard.setSlamming(false);
					phase = 2;
					timer = 0;
				}
			}
			case 2 -> {
				if (timer >= RECOVER_TICKS) {
					phase = 3;
				}
			}
			default -> {
			}
		}
	}

	private void hold() {
		double hy = guard.getY() + guard.getHeight() + 0.2;
		victim.requestTeleport(guard.getX(), hy, guard.getZ());
		victim.setVelocity(Vec3d.ZERO);
		victim.fallDistance = 0.0f;
		if (victim instanceof MobEntity m) {
			m.getNavigation().stop();
		}
	}

	private void slam() {
		if (!(guard.getWorld() instanceof ServerWorld w)) {
			return;
		}
		Vec3d look = Vec3d.fromPolar(0.0f, guard.getYaw()).multiply(2.5);
		double x = guard.getX() + look.x;
		double z = guard.getZ() + look.z;

		BlockPos.Mutable p = new BlockPos.Mutable(x, guard.getY() + 1.0, z);
		int tries = 0;
		while (w.getBlockState(p).isAir() && p.getY() > w.getBottomY() && tries++ < 6) {
			p.move(Direction.DOWN);
		}
		BlockPos ground = p.toImmutable();
		double topY = ground.getY() + 1.0;

		victim.requestTeleport(x, topY, z);
		makeCrater(w, ground);

		// partikel & suara ledakan besar
		w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, x, topY + 0.5, z, 3, 1.5, 0.3, 1.5, 0.0);
		w.spawnParticles(ParticleTypes.EXPLOSION, x, topY + 0.5, z, 50, 2.5, 0.6, 2.5, 0.1);
		w.spawnParticles(ParticleTypes.CLOUD, x, topY + 0.3, z, 80, 3.0, 0.3, 3.0, 0.2);
		w.spawnParticles(ParticleTypes.LARGE_SMOKE, x, topY + 0.5, z, 40, 2.5, 0.5, 2.5, 0.05);
		w.playSound(null, x, topY, z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.HOSTILE, 4.0f, 0.6f);
		w.playSound(null, x, topY, z, SoundEvents.ENTITY_IRON_GOLEM_ATTACK, SoundCategory.HOSTILE, 2.0f, 0.5f);

		// gelombang kejut kecil ke makhluk lain di sekitar
		for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class,
				new net.minecraft.util.math.Box(x - 5, topY - 2, z - 5, x + 5, topY + 4, z + 5),
				e -> e != victim && e != guard && !(e instanceof SheepKingEntity) && !(e instanceof BodyguardEntity))) {
			Vec3d d = e.getPos().subtract(x, e.getY(), z);
			double len = Math.max(0.5, d.length());
			e.addVelocity(d.x / len * 0.8, 0.5, d.z / len * 0.8);
			e.velocityModified = true;
		}

		// bantingan mematikan
		victim.timeUntilRegen = 0;
		victim.damage(w.getDamageSources().mobAttack(guard), 80.0f);
	}

	private void makeCrater(ServerWorld w, BlockPos center) {
		if (!w.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
			return;
		}
		int r = CRATER_RADIUS;
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				double d = Math.sqrt(dx * dx + dz * dz);
				if (d > r) {
					continue;
				}
				int depth = (int) Math.ceil((1.0 - d / r) * 3.0);
				for (int dy = 0; dy < depth; dy++) {
					BlockPos bp = center.add(dx, -dy, dz);
					BlockState s = w.getBlockState(bp);
					if (s.isAir() || s.isOf(Blocks.BEDROCK) || s.hasBlockEntity() || s.getHardness(w, bp) < 0) {
						continue;
					}
					if (w.random.nextInt(3) == 0) {
						w.syncWorldEvent(2001, bp, net.minecraft.block.Block.getRawIdFromState(s));
					}
					w.setBlockState(bp, Blocks.AIR.getDefaultState(), 3);
				}
			}
		}
	}
}
