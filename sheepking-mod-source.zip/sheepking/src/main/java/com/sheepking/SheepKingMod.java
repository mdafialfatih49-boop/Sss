package com.sheepking;

import net.fabricmc.api.ModInitializer;

public class SheepKingMod implements ModInitializer {
	public static final String MOD_ID = "sheepking";

	@Override
	public void onInitialize() {
		ModEntities.register();
	}
}
