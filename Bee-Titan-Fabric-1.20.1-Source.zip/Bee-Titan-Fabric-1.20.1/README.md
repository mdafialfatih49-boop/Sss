# Bee Titan — Fabric 1.20.1

Mod sumber Fabric 1.20.1 yang menambahkan monster raksasa bertema lebah berdasarkan gambar referensi.

## Fitur
- Model humanoid lebah berlapis armor kuning, kepala lebah, antena, sayap, abdomen, dan sengat.
- Entity sekitar 3,55 blok dengan 420 HP, armor tinggi, serta pukulan kuat.
- Animasi GeckoLib dalam format yang dapat diedit melalui Blockbench + plugin GeckoLib: idle, walk, run, punch, roar, slam, dash.
- Ability:
  - **Heavy Punch** — pukulan jarak dekat dengan knockback besar.
  - **Royal Roar** — gelombang area, partikel, suara raungan, damage, dan knockback.
  - **Ground Slam** — hentakan area dengan awan debu dan partikel.
  - **Wing Dash** — dorongan cepat untuk mendekati target.
  - **Bee Guards** — memanggil tiga lebah penjaga untuk sementara.
- Spawn egg di tab Spawn Eggs.
- Spawn alami sangat langka di Plains, Sunflower Plains, Meadow, dan Flower Forest.

## Dependensi
- Minecraft Java 1.20.1
- Fabric Loader 0.15+
- Fabric API
- GeckoLib Fabric 4.4.9+
- Java 17
- Gradle 8.8

GeckoLib wajib dipasang juga pada client Minecraft. Tanpa GeckoLib, game tidak dapat memuat mod ini.

## Spawn dalam game
- Spawn egg: **Bee Titan Spawn Egg** pada tab Spawn Eggs.
- Command: `/summon beetitan:bee_titan`.

## Build lokal
```bash
gradle build
```
JAR hasil build ada di `build/libs/`.

## Build dengan GitHub Actions
1. Ekstrak ZIP ini.
2. Upload isi folder proyek ke sebuah repository GitHub.
3. Pastikan `build.gradle`, `gradle.properties`, `settings.gradle`, `src/`, dan `.github/` berada di root repository.
4. Buka tab **Actions** lalu jalankan **Build Bee Titan Mod**.
5. Unduh artifact `Bee-Titan-Fabric-1.20.1` dari hasil workflow.

## Mengedit model dan animasi di Blockbench
File model dan animasi GeckoLib yang bisa diedit:
- `src/main/resources/assets/beetitan/geo/bee_titan.geo.json`
- `src/main/resources/assets/beetitan/animations/bee_titan.animation.json`
- `src/main/resources/assets/beetitan/textures/entity/bee_titan.png`

Buka Blockbench, pasang plugin GeckoLib, lalu import model GeckoLib dan animation file tersebut. Pastikan nama bone tetap sama (`body`, `head`, `arm_left`, `arm_right`, `leg_left`, `leg_right`, `wing_left`, `wing_right`) karena dipakai oleh file animasi.

## Catatan
Ini adalah source project awal yang disusun untuk target 1.20.1. Build Gradle belum dijalankan di lingkungan pembuatan ini karena Gradle tidak tersedia; gunakan workflow Actions untuk pemeriksaan kompilasi dan JAR final. Jika Actions melaporkan error kompilasi, kirim log error lengkap agar kelas atau pemanggilan API yang berbeda dapat diperbaiki.
