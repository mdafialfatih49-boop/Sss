package com.beetitan;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.BiomeKeys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BeeTitanMod implements ModInitializer {
    public static final String MOD_ID = "beetitan";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final net.minecraft.entity.EntityType<BeeTitanEntity> BEE_TITAN =
            Registry.register(
                    Registries.ENTITY_TYPE,
                    id("bee_titan"),
                    FabricEntityTypeBuilder.<BeeTitanEntity>create(SpawnGroup.MONSTER, BeeTitanEntity::new)
                            .dimensions(EntityDimensions.fixed(1.85F, 3.55F))
                            .trackRangeBlocks(96)
                            .trackedUpdateRate(2)
                            .build()
            );

    public static final Item BEE_TITAN_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            id("bee_titan_spawn_egg"),
            new SpawnEggItem(BEE_TITAN, 0xEBAA19, 0x261A12, new Item.Settings())
    );

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                BEE_TITAN, BeeTitanEntity.createBeeTitanAttributes()
        );

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(BEE_TITAN_SPAWN_EGG));

        // Very rare natural appearance in flower-rich overworld biomes.
        BiomeModifications.addSpawn(
                BiomeSelectors.includeByKey(
                        BiomeKeys.FLOWER_FOREST,
                        BiomeKeys.PLAINS,
                        BiomeKeys.SUNFLOWER_PLAINS,
                        BiomeKeys.MEADOW
                ),
                SpawnGroup.MONSTER,
                BEE_TITAN,
                1,
                1,
                1
        );

        SpawnRestriction.register(
                BEE_TITAN,
                SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                HostileEntity::canSpawnInDark
        );

        LOGGER.info("Bee Titan is ready. Its honey is definitely not ordinary.");
    }
}
