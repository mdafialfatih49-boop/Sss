package com.beetitan;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.mob.Angerable;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class BeeTitanEntity extends HostileEntity implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.bee_titan.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.bee_titan.walk");
    private static final RawAnimation RUN = RawAnimation.begin().thenLoop("animation.bee_titan.run");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    private int roarCooldown = 100;
    private int slamCooldown = 70;
    private int swarmCooldown = 180;
    private int dashCooldown = 100;
    private int dashTicks = 0;

    public BeeTitanEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.experiencePoints = 45;
    }

    public static DefaultAttributeContainer.Builder createBeeTitanAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 420.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 24.0D)
                .add(EntityAttributes.GENERIC_ARMOR, 18.0D)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.12D, true));
        this.goalSelector.add(6, new WanderAroundFarGoal(this, 0.72D));
        this.goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 18.0F));
        this.goalSelector.add(8, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();

        if (this.roarCooldown > 0) this.roarCooldown--;
        if (this.slamCooldown > 0) this.slamCooldown--;
        if (this.swarmCooldown > 0) this.swarmCooldown--;
        if (this.dashCooldown > 0) this.dashCooldown--;
        if (this.dashTicks > 0 && --this.dashTicks == 0) this.setSprinting(false);

        if (this.getWorld().isClient || this.getTarget() == null || !this.getTarget().isAlive()) {
            return;
        }

        LivingEntity target = this.getTarget();
        double distanceSq = this.squaredDistanceTo(target);

        // Close-range signature move: a heavy ground impact.
        if (distanceSq <= 20.25D && this.slamCooldown <= 0 && this.isOnGround()) {
            groundSlam();
            this.slamCooldown = 220;
            return;
        }

        // A roar controls space when its target is at medium range.
        if (distanceSq > 36.0D && distanceSq <= 256.0D && this.roarCooldown <= 0) {
            royalRoar();
            this.roarCooldown = 300;
            return;
        }

        // A short burst of speed closes the gap.
        if (distanceSq > 30.0D && distanceSq <= 144.0D && this.dashCooldown <= 0) {
            dashToward(target);
            this.dashCooldown = 180;
        }

        // Occasionally call a few ordinary bees as temporary guards.
        if (distanceSq <= 225.0D && this.swarmCooldown <= 0) {
            summonGuards(target);
            this.swarmCooldown = 420;
        }
    }

    private void royalRoar() {
        this.triggerAnim("action", "roar");

        this.getWorld().playSound(
                null, this.getBlockPos(), SoundEvents.ENTITY_RAVAGER_ROAR,
                SoundCategory.HOSTILE, 2.7F, 0.72F
        );

        if (!(this.getWorld() instanceof ServerWorld serverWorld)) return;

        serverWorld.spawnParticles(ParticleTypes.CLOUD,
                this.getX(), this.getY() + 1.2D, this.getZ(),
                46, 2.7D, 0.9D, 2.7D, 0.12D);
        serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                this.getX(), this.getY() + 1.6D, this.getZ(),
                26, 2.0D, 1.0D, 2.0D, 0.08D);

        for (Entity entity : this.getWorld().getOtherEntities(this, this.getBoundingBox().expand(7.0D, 3.0D, 7.0D))) {
            if (entity instanceof LivingEntity living && canHit(living)) {
                living.damage(this.getDamageSources().mobAttack(this), 8.0F);
                pushAway(living, 1.15D, 0.42D);
            }
        }
    }

    private void groundSlam() {
        this.triggerAnim("action", "slam");
        this.getWorld().playSound(
                null, this.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE,
                SoundCategory.HOSTILE, 2.1F, 0.62F
        );

        if (!(this.getWorld() instanceof ServerWorld serverWorld)) return;

        serverWorld.spawnParticles(ParticleTypes.EXPLOSION,
                this.getX(), this.getY() + 0.2D, this.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
        serverWorld.spawnParticles(ParticleTypes.CLOUD,
                this.getX(), this.getY() + 0.15D, this.getZ(),
                65, 3.8D, 0.15D, 3.8D, 0.18D);
        serverWorld.spawnParticles(ParticleTypes.CRIT,
                this.getX(), this.getY() + 0.4D, this.getZ(),
                34, 3.0D, 0.4D, 3.0D, 0.12D);

        for (Entity entity : this.getWorld().getOtherEntities(this, this.getBoundingBox().expand(5.2D, 2.5D, 5.2D))) {
            if (entity instanceof LivingEntity living && canHit(living)) {
                living.damage(this.getDamageSources().mobAttack(this), 17.0F);
                pushAway(living, 1.65D, 0.72D);
            }
        }
    }

    private void dashToward(LivingEntity target) {
        this.triggerAnim("action", "dash");
        Vec3d direction = target.getPos().subtract(this.getPos()).normalize();
        this.setVelocity(
                direction.x * 1.55D,
                Math.max(this.getVelocity().y, 0.18D),
                direction.z * 1.55D
        );
        this.velocityModified = true;
        this.setSprinting(true);
        this.dashTicks = 14;

        if (this.getWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 0.8D, this.getZ(),
                    20, 0.8D, 0.4D, 0.8D, 0.08D);
            serverWorld.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                    this.getX(), this.getY() + 1.2D, this.getZ(),
                    10, 0.6D, 0.7D, 0.6D, 0.04D);
        }
    }

    private void summonGuards(LivingEntity target) {
        if (!(this.getWorld() instanceof ServerWorld serverWorld)) return;

        for (int i = 0; i < 3; i++) {
            BeeEntity bee = net.minecraft.entity.EntityType.BEE.create(serverWorld);
            if (bee == null) continue;

            double angle = (Math.PI * 2.0D * i) / 3.0D;
            double x = this.getX() + Math.cos(angle) * 2.0D;
            double z = this.getZ() + Math.sin(angle) * 2.0D;

            bee.refreshPositionAndAngles(x, this.getY() + 1.0D, z, this.getYaw(), 0.0F);
            bee.setPersistent();
            Angerable anger = bee;
            anger.setAngryAt(target.getUuid());
            anger.setAngerTime(400);
            bee.setTarget(target);
            serverWorld.spawnEntity(bee);
        }

        serverWorld.spawnParticles(ParticleTypes.WAX_ON,
                this.getX(), this.getY() + 1.5D, this.getZ(),
                22, 1.2D, 0.8D, 1.2D, 0.04D);
        this.getWorld().playSound(
                null, this.getBlockPos(), SoundEvents.ENTITY_BEE_LOOP,
                SoundCategory.HOSTILE, 1.8F, 0.7F
        );
    }

    private boolean canHit(LivingEntity living) {
        return living != this
                && living.isAlive()
                && !(living instanceof BeeEntity)
                && !(living instanceof BeeTitanEntity);
    }

    private void pushAway(LivingEntity target, double strength, double vertical) {
        Vec3d direction = target.getPos().subtract(this.getPos());
        if (direction.lengthSquared() < 0.0001D) {
            direction = new Vec3d(0.0D, 0.0D, 1.0D);
        } else {
            direction = direction.normalize();
        }
        target.addVelocity(direction.x * strength, vertical, direction.z * strength);
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean successful = super.tryAttack(target);
        if (successful && !this.getWorld().isClient) {
            this.triggerAnim("action", "punch");
            if (target instanceof LivingEntity living) {
                pushAway(living, 1.3D, 0.38D);
            }
        }
        return successful;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BEE_LOOP;
    }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) {
        return SoundEvents.ENTITY_IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_IRON_GOLEM_DEATH;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 4, this::movementPredicate));
        AnimationController<BeeTitanEntity> actionController =
                new AnimationController<>(this, "action", 0, state -> PlayState.STOP);

        actionController
                .triggerableAnim("punch", RawAnimation.begin().thenPlay("animation.bee_titan.punch"))
                .triggerableAnim("roar", RawAnimation.begin().thenPlay("animation.bee_titan.roar"))
                .triggerableAnim("slam", RawAnimation.begin().thenPlay("animation.bee_titan.slam"))
                .triggerableAnim("dash", RawAnimation.begin().thenPlay("animation.bee_titan.dash"));

        controllers.add(actionController);
    }

    private PlayState movementPredicate(AnimationState<BeeTitanEntity> state) {
        if (this.isSprinting() || this.getVelocity().horizontalLengthSquared() > 0.12D) {
            state.setAnimation(RUN);
        } else if (state.isMoving()) {
            state.setAnimation(WALK);
        } else {
            state.setAnimation(IDLE);
        }
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
