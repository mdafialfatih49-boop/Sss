package com.beetitan.client;

import com.beetitan.BeeTitanMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class BeeTitanClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(BeeTitanMod.BEE_TITAN, BeeTitanRenderer::new);
    }
}
