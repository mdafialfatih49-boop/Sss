package com.beetitan.client;

import com.beetitan.BeeTitanMod;
import com.beetitan.BeeTitanEntity;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

public class BeeTitanModel extends GeoModel<BeeTitanEntity> {
    @Override
    public Identifier getModelResource(BeeTitanEntity animatable) {
        return BeeTitanMod.id("geo/bee_titan.geo.json");
    }

    @Override
    public Identifier getTextureResource(BeeTitanEntity animatable) {
        return BeeTitanMod.id("textures/entity/bee_titan.png");
    }

    @Override
    public Identifier getAnimationResource(BeeTitanEntity animatable) {
        return BeeTitanMod.id("animations/bee_titan.animation.json");
    }
}
