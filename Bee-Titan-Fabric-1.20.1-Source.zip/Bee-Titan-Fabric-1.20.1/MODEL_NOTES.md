# Model / Blockbench notes

The model is exported in GeckoLib Bedrock geometry JSON format and uses the GeckoLib 4 animation JSON format.
It is intentionally separated into bones for editing and retiming in Blockbench.

## Main bones
- `body`: torso and abdominal armor
- `head`: bee face / mask
- `antenna_left`, `antenna_right`: antennae
- `arm_left`, `arm_right`: oversized fists and forearms
- `leg_left`, `leg_right`: legs / feet
- `wing_left`, `wing_right`: small rear wings
- `abdomen`: rear abdomen and stinger

The renderer stretches the exported model vertically so the visible model matches the large entity hitbox.
The texture is a custom pixel-art atlas made for this model. If a cuboid is moved in Blockbench, re-check its UV placement.
